#pragma once

#include <vector>

#include "scene.h"
#include "mesh.h"
#include "shader.h"
#include "texture.h"

struct cloth_t
{
	int rows;
	int cols;
	float len;
	
	std::vector<glm::vec3> nodes;
	std::vector<glm::ivec2> links;
	std::vector<glm::ivec3> patches;

	std::vector<transform_t*> transforms;
	std::vector<collider_t*> colliders;	
	renderer_t* renderer;
};

cloth_t cloth_init(scene_t& scene, int rows, int cols, float len)
{
	std::vector<glm::vec3> nodes = std::vector<glm::vec3>();
	std::vector<glm::ivec2> links = std::vector<glm::ivec2>();
	std::vector<glm::ivec3> patches = std::vector<glm::ivec3>();

	for(int row = 0; row < rows; row++)
	{
		for(int col = 0; col < cols; col++)
		{
			nodes.push_back(len * glm::vec3(col, -row, 0));
			
			int tl = row * cols + col;
			int tr = row * cols + (col+1);
			int br = (row+1) * cols + (col+1);
			int bl = (row+1) * cols + col;

			bool tr_in_bounds = col+1 < cols;
			bool bl_in_bounds = row+1 < rows;
			bool br_in_bounds = tr_in_bounds && bl_in_bounds;

			if(tr_in_bounds)
			{ links.push_back(glm::ivec2(tl, tr)); }
			if(bl_in_bounds)
			{ links.push_back(glm::ivec2(tl, bl)); }
			if(br_in_bounds)
			{
				patches.push_back(glm::ivec3(bl, tl, tr));
				patches.push_back(glm::ivec3(tr, br, bl));
			}
		}
	}

	std::vector<vertex_t> verts = std::vector<vertex_t>();
	for(glm::ivec3 patch : patches)
	{
		glm::vec3 a_pos = nodes[patch.x];
		glm::vec3 b_pos = nodes[patch.y];
		glm::vec3 c_pos = nodes[patch.z];

		glm::vec3 ab = b_pos - a_pos;
		glm::vec3 ac = c_pos - a_pos;
		glm::vec3 norm = glm::cross(ab, ac);

		int a_row = patch.x / cols;
		int a_col = patch.x % cols;
		int b_row = patch.y / cols;
		int b_col = patch.y % cols;
		int c_row = patch.z / cols;
		int c_col = patch.z % cols;
		glm::vec2 a_uv = glm::vec2(a_col / (float) (cols-1), a_row / (float) (rows-1));
		glm::vec2 b_uv = glm::vec2(b_col / (float) (cols-1), b_row / (float) (rows-1));
		glm::vec2 c_uv = glm::vec2(c_col / (float) (cols-1), c_row / (float) (rows-1));

		verts.push_back({a_pos, a_uv, norm});
		verts.push_back({b_pos, b_uv, norm});
		verts.push_back({c_pos, c_uv, norm});
	}
	mesh_t mesh = mesh_init(verts, GL_TRIANGLES);

	cloth_t cloth;
	cloth.rows = rows;
	cloth.cols = cols;
	cloth.len = len;
	cloth.nodes = nodes;
	cloth.links = links;
	cloth.patches = patches;
	cloth.transforms = std::vector<transform_t*>();
	for(int i = 0; i < nodes.size(); i++)
	{
		sphere_t sphere = sphere_init(glm::vec3(0), len*0.25);
		collider_t collider = collider_sphere_init(sphere);
		add_entity(scene, transform_init(nodes[i]), collider, renderer_init());
		cloth.transforms.push_back(scene.transforms + scene.n_entities-1);
		toggle_gizmo(scene, scene.n_entities-1, true);
	}
	add_entity
	(
		scene, transform_init(glm::vec3(0)), collider_init(),
		renderer_init(mesh, scene.shader_bank["mesh"], scene.texture_bank["uv"])
	);
	cloth.renderer = scene.renderers + scene.n_entities-1;
	return cloth;
}

void update_cloth_physics(cloth_t& cloth, int ssteps, int rsteps, float dt)
{
	dt /= ssteps;

	for(int s = 0; s < ssteps; s++)
	{
		// Pre-Solve
		glm::vec3 precord[cloth.transforms.size()];
		for(int i = 0; i < cloth.transforms.size(); i++)
		{
			precord[i] = cloth.transforms[i]->position;
			cloth.transforms[i]->velocity += glm::vec3(0, -9.81f, 0) * dt;
			cloth.transforms[i]->position += cloth.transforms[i]->velocity * dt;
		}

		// Solve
		for(int r = 0; r < rsteps; r++)
		{
			for(glm::ivec2 link : cloth.links)
			{
				transform_t* a = cloth.transforms[link.x];	
				transform_t* b = cloth.transforms[link.y];
				glm::vec3 delta = b->position - a->position;
				float delta_len = glm::length(delta);
				if(delta_len == 0)
				{ continue; }
				glm::vec3 delta_dir = delta / delta_len;
				float error = delta_len - cloth.len;
				a->position += 0.5f * error * delta_dir;
				b->position -= 0.5f * error * delta_dir;
			}
		}
		cloth.transforms[0]->position = cloth.len * glm::vec3(0,0,0);
		cloth.transforms[cloth.cols-1]->position = cloth.len * glm::vec3(cloth.cols-1, 0, 0);

		// Post-Solve
		for(int i = 0; i < cloth.transforms.size(); i++)
		{ cloth.transforms[i]->velocity = (cloth.transforms[i]->position - precord[i]) / dt; }
	}
}

void update_cloth_mesh(cloth_t& cloth)
{
	for(int i = 0; i < cloth.patches.size(); i++)
	{
		glm::ivec3 patch = cloth.patches[i];

		int a_idx = i * 3 + 0;
		int b_idx = i * 3 + 1;
		int c_idx = i * 3 + 2;

		glm::vec3 a_pos = cloth.transforms[patch.x]->position;
		glm::vec3 b_pos = cloth.transforms[patch.y]->position;
		glm::vec3 c_pos = cloth.transforms[patch.z]->position;
		glm::vec3 ab = b_pos - a_pos;
		glm::vec3 ac = c_pos - a_pos;
		glm::vec3 norm = glm::cross(ab, ac);
		
		cloth.renderer->mesh.verts[a_idx].pos = a_pos;
		cloth.renderer->mesh.verts[b_idx].pos = b_pos;
		cloth.renderer->mesh.verts[c_idx].pos = c_pos;
		cloth.renderer->mesh.verts[a_idx].norm = norm;
		cloth.renderer->mesh.verts[b_idx].norm = norm;
		cloth.renderer->mesh.verts[c_idx].norm = norm;
	}

	glBindBuffer(GL_ARRAY_BUFFER, cloth.renderer->mesh.vbo_id);
	glBufferData(GL_ARRAY_BUFFER, cloth.renderer->mesh.verts.size() * sizeof(vertex_t), cloth.renderer->mesh.verts.data(), GL_STATIC_DRAW);
}

