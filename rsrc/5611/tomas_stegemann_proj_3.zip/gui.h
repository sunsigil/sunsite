#pragma once

#include <vector>
#include <string>

#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include "misc/cpp/imgui_stdlib.h"

#include "camera.h"
#include "window.h"
#include "scene.h"

struct gui_state_t
{
	std::string mesh_name = "";
	std::string texture_name = "";
	glm::vec3 mesh_scale = glm::vec3(1);
	bool strong_erase = false;
	bool clamp_arm = false;
};

void draw_combo_field(std::string& str, std::vector<std::string> options, std::string label)
{
	ImGui::PushID(&str);
	if(ImGui::BeginCombo(label.c_str(), str.c_str()))
	{
		for(std::string option : options)
		{
			if(ImGui::Selectable(option.c_str(), option == str))
			{ str = option; }
		}
		ImGui::EndCombo();
	}
	ImGui::PopID();
}

void render_gui(gui_state_t& state, window_t& window, scene_t& scene, camera_t& camera, float dt)
{
	ImGui_ImplGlfw_NewFrame();
	ImGui_ImplOpenGL3_NewFrame();
	ImGui::NewFrame();
	ImGui::SetNextWindowPos(ImVec2(0, 0));
	ImGui::SetNextWindowSize(ImVec2(window.dimensions.x, window.dimensions.y));
	ImGui::Begin("##window", nullptr, window.flags);
	ImGui::PushItemWidth(window.dimensions.x * 0.125f);

	ImGui::Text(window.paused ? "PAUSED" : "PLAYING");
	ImGui::Text(window.renderer_str.c_str());
	ImGui::Text(window.version_str.c_str());

	int n_prims = 0;
	for(int i = 0; i < scene.n_entities; i++)
	{
		if(scene.renderers[i].enabled)
		{
			mesh_t& mesh = scene.renderers[i].mesh;
			int n_verts = mesh.verts.size();
			if(mesh.mode == GL_TRIANGLES)
			{ n_prims += n_verts / 3; }
			else if(mesh.mode == GL_LINES)
			{ n_prims += n_verts / 2; }
		}
	}
	ImGui::Text("%d entities (%d primitives)", scene.n_entities, n_prims);
	ImGui::Text("%.1f FPS", 1.0f/dt);

	draw_combo_field(state.mesh_name, get_keys(scene.mesh_bank), "mesh name");
	draw_combo_field(state.texture_name, get_keys(scene.texture_bank), "texture name");
	ImGui::InputFloat3("mesh scale", glm::value_ptr(state.mesh_scale));
	if
	(
		ImGui::Button("spawn") &&
		state.mesh_name.size() > 0 && state.texture_name.size() > 0 &&
		(state.mesh_scale.x > 0 || state.mesh_scale.y > 0 || state.mesh_scale.z > 0)
	)
	{
		glm::vec3 spawn_dir = make_forward(camera.transform);
		glm::vec3 spawn_pos = camera.transform.position + spawn_dir * 5.0f;
		transform_t transform = transform_init(spawn_pos);
		transform.scale = state.mesh_scale;

		renderer_t renderer = renderer_init
		(
			scene.mesh_bank[state.mesh_name],
			scene.shader_bank["mesh"],
			scene.texture_bank[state.texture_name]
		);
		
		add_entity(scene, transform, collider_init(), renderer); 
	}

	if(ImGui::Button("reset camera"))
	{
		camera.transform.position = glm::vec3();
		camera.transform.orientation = glm::quat();
	}
	if(ImGui::Button("reset scene"))
	{ scene_erase(scene, state.strong_erase); }
	ImGui::SameLine();
	ImGui::Checkbox("hard", &state.strong_erase);
	ImGui::Checkbox("clamp arm", &state.clamp_arm);

	ImGui::PopItemWidth();
	ImGui::End();
	ImGui::Render();
	ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

