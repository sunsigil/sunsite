#pragma once

#include <string>
#include <iostream>
#include <stdio.h>
#include <stdint.h>

#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>
#include <GL/glew.h> 

#include "png.h"

struct PNG_t
{
	uint32_t width;
	uint32_t height;
	int colour_type;
	int depth;

	GLubyte* data;
};

// It's about to get very Jack Kolb in here
PNG_t PNG_init(std::string path)
{
	PNG_t png = {0, 0, 0, 0, nullptr};

	FILE* file = fopen(path.c_str(), "rb");
	if(file == NULL)
	{
		std::cerr << "error: failed to open " << path << std::endl;
		return png;
	}

	png_structp image = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if(image == NULL)
	{
		std::cerr << "error: failed to create png_structp for " << path << std::endl;
		fclose(file);
		return png;
	}
	
	png_infop info = png_create_info_struct(image);
	if(info == NULL)
	{
		std::cerr << "error: failed to create png_infop for " << path << std::endl;
		png_destroy_read_struct(&image, NULL, NULL);
		fclose(file);
		return png;
	}

	if(setjmp(png_jmpbuf(image)))
	{
		std::cerr << "error: png_jmpbuf triggered for " << path << std::endl;
		png_destroy_read_struct(&image, &info, NULL);
		fclose(file);
		return png;
	}

	png_init_io(image, file);
	png_set_sig_bytes(image, 0);
	png_read_png(image, info, PNG_TRANSFORM_STRIP_16 | PNG_TRANSFORM_PACKING | PNG_TRANSFORM_EXPAND, NULL);

	png_uint_32 width;
	png_uint_32 height;
	int depth;
	int colour_type;
	int interlace_type;
	png_get_IHDR(image, info, &width, &height, &depth, &colour_type, &interlace_type, NULL, NULL);
	bool alpha = colour_type == PNG_COLOR_TYPE_RGBA || colour_type == PNG_COLOR_TYPE_GA;
	int row_size = png_get_rowbytes(image, info);
	int size = sizeof(GLubyte) * row_size * height;

	GLubyte* data = (GLubyte*) malloc(size);
	png_bytepp rows = png_get_rows(image, info);
	for(int i = 0; i < height; i++)
	{ memcpy(data + row_size * i, rows[i], row_size); }
	
	png_destroy_read_struct(&image, &info, NULL);
	fclose(file);

	png = {width, height, colour_type, depth, data};
	return png;
}
