#pragma once

#include <stdlib.h>
#include <math.h>
#include <vector>

#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>
#include <GL/glew.h> 

#include <glm/glm.hpp>
#include <glm/gtx/string_cast.hpp>

#include "mesh.h"

struct bath_t
{
	int n;
	float dx;
	float scale;

	float* h;
	float* hu;
};

bath_t bath_init(int n)
{
	bath_t bath;
	bath.n = n;
	bath.dx = 1.0f/n;

	bath.h = (float*) malloc(sizeof(float) * n);
	bath.hu = (float*) malloc(sizeof(float) * n);
	for(int i = 0; i < n; i++)
	{
		bath.h[i] = 2*i/n+1;
		bath.hu[i] = 0.0f; 
	}

	return bath;
}

void bath_dispose(bath_t& bath)
{
	free(bath.h);
	free(bath.hu);
}

void bath_swe(bath_t& bath, float dt)
{
	float g = 1.0f;
	float damp = 0.9f;
	
	float* dhdt = (float*) malloc(sizeof(float) * bath.n);
	float* dhudt = (float*) malloc(sizeof(float) * bath.n);
	float* h_mid = (float*) malloc(sizeof(float) * bath.n);
	float* hu_mid = (float*) malloc(sizeof(float) * bath.n);
	float* dhdt_mid = (float*) malloc(sizeof(float) * bath.n);
	float* dhudt_mid = (float*) malloc(sizeof(float) * bath.n);

	for(int i = 0; i < bath.n-1; i++)
	{
		h_mid[i] = 0.5 * (bath.h[i] + bath.h[i+1]);
		hu_mid[i] = 0.5 * (bath.hu[i] + bath.hu[i+1]);
	}

	for(int i = 0; i < bath.n-1; i++)
	{
		float dhudx_mid = (bath.hu[i+1] - bath.hu[i])/bath.dx;
		dhdt_mid[i] = -dhudx_mid;

		float dhu2dx_mid = (bath.hu[i+1]*bath.hu[i+1]/bath.h[i+1] - bath.hu[i]*bath.hu[i]/bath.h[i]) / bath.dx;
 		float dgh2dx_mid = (g*bath.h[i+1]*bath.h[i+1] - bath.h[i]*bath.h[i]) / bath.dx;
 		dhudt_mid[i] = -(dhu2dx_mid + 0.5*dgh2dx_mid);
	}
	
	for(int i = 0; i < bath.n; i++)
	{
		h_mid[i] += dhdt_mid[i] * 0.5f*dt;
		hu_mid[i] += dhudt_mid[i] * 0.5f*dt;
	}

	for(int i = 0; i < bath.n-1; i++)
	{
		float dhudx = (hu_mid[i] - hu_mid[i-1]) / bath.dx;
		dhdt[i] = -dhudx;

		float dhu2dx = (hu_mid[i]*hu_mid[i]/h_mid[i] - hu_mid[i-1]*hu_mid[i-1]/h_mid[i-1]) / bath.dx;
 		float dgh2dx = g*(h_mid[i]*h_mid[i] - h_mid[i-1]*h_mid[i-1]) / bath.dx;
 		dhudt[i] = -(dhu2dx + 0.5*dgh2dx);
	}

	for(int i = 0; i < bath.n; i++)
	{
		bath.h[i] += damp*dhdt[i]*dt;
		bath.hu[i] += damp*dhudt[i]*dt;
	}

	bath.h[0] = bath.h[1];
	bath.h[bath.n-1] = bath.h[bath.n-2];
	bath.hu[0] = -bath.hu[1];
	bath.hu[bath.n-1] = -bath.hu[bath.n-2];

	free(dhdt);
	free(dhudt);
	free(h_mid);
	free(hu_mid);
	free(dhdt_mid);
	free(dhudt_mid);
}

vertex_t bath_vertex(bath_t& bath, int i)
{
	glm::vec3 pos = glm::vec3(i*bath.dx, bath.h[i], 0);
	glm::vec2 uv = glm::vec2(i/bath.n-1, bath.h[i]);
	float tangent = bath.h[(i+1)%bath.n] - bath.h[i];
	glm::vec3 normal = glm::vec3(-tangent, bath.dx, 0);
	return (vertex_t){pos, uv, normal};
}

mesh_t bath_mesh(bath_t& bath)
{
	std::vector<vertex_t> verts = std::vector<vertex_t>();
	for(int i = 0; i < bath.n-1; i++)
	{
		verts.push_back(bath_vertex(bath, i));
		verts.push_back(bath_vertex(bath, i+1));
	}
	return mesh_init(verts, GL_LINES);
}

