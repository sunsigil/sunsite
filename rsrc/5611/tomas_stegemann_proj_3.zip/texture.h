#pragma once

#include <string>
#include <iostream>
#include <stdio.h>

#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>
#include <GL/glew.h> 

#include "tos_png.h"

struct texture_t
{
	int width;
	int height;

	GLuint tex_id;
	GLubyte* data;
	GLenum mode; 
	GLenum channels;
};

texture_t texture_init(GLubyte* data, int width, int height, GLenum channels)
{
	GLuint tex_id; 
	glGenTextures(1, &tex_id);
	glBindTexture(GL_TEXTURE_2D, tex_id);
	glTexParameteri(tex_id, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(tex_id, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(tex_id, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(tex_id, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexImage2D(GL_TEXTURE_2D, 0, channels, width, height, 0, channels, GL_UNSIGNED_BYTE, data);
	glGenerateMipmap(GL_TEXTURE_2D);

	texture_t texture;
	texture.width = width;
	texture.height = height;
	texture.tex_id = tex_id;
	texture.data = data;
	texture.mode = GL_TEXTURE_2D;
	texture.channels = channels;

	return texture;
}

texture_t cubemap_init(GLubyte* data, int width, int height, GLenum channels)
{
	GLuint tex_id;
	glGenTextures(1, &tex_id);
	glBindTexture(GL_TEXTURE_CUBE_MAP, tex_id);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);  
	glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X, 0, channels, width, height, 0, channels, GL_UNSIGNED_BYTE, data);
	glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_X, 0, channels, width, height, 0, channels, GL_UNSIGNED_BYTE, data);
	glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_Y, 0, channels, width, height, 0, channels, GL_UNSIGNED_BYTE, data);
	glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_Y, 0, channels, width, height, 0, channels, GL_UNSIGNED_BYTE, data);
	glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_Z, 0, channels, width, height, 0, channels, GL_UNSIGNED_BYTE, data);
	glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_Z, 0, channels, width, height, 0, channels, GL_UNSIGNED_BYTE, data);
	glGenerateMipmap(GL_TEXTURE_CUBE_MAP);
	
	texture_t texture;
	texture.width = width;
	texture.height = height;
	texture.tex_id = tex_id;
	texture.data = data;
	texture.mode = GL_TEXTURE_CUBE_MAP;
	texture.channels = channels;

	return texture;
}

texture_t texture_PNG_init(PNG_t png)
{
	return texture_init
	(
		png.data,
		png.width, png.height,
		png.colour_type == PNG_COLOR_TYPE_RGBA ?
		GL_RGBA :
		GL_RGB
	);
}

texture_t cubemap_PNG_init(PNG_t png)
{
	return cubemap_init
	(
		png.data,
		png.width, png.height,
		png.colour_type == PNG_COLOR_TYPE_RGBA ?
		GL_RGBA :
		GL_RGB
	);
}

void texture_dispose(const texture_t& texture)
{
	free(texture.data);
}

