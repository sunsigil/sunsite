#pragma once

#include <map>

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>

#include "transform.h"
#include "collider.h"
#include "render.h"
#include "camera.h"
#include "assets.h"

struct scene_t
{
	std::map<std::string, shader_t> shader_bank;
	std::map<std::string, texture_t> texture_bank;
	std::map<std::string, mesh_t> mesh_bank;
	std::map<shape_type_t, mesh_t> shape_mesh_bank;

	transform_t* transforms;
	collider_t* colliders;
	renderer_t* renderers;
	renderer_t* gizmos;

	int max_entities;
	int n_entities;
	int bookmark;
};

scene_t scene_init(int max_entities)
{
	scene_t scene;

	scene.shader_bank = load_shaders("shader");
	scene.texture_bank = load_textures("img");
	scene.mesh_bank = load_meshes("mesh");

	scene.shape_mesh_bank = std::map<shape_type_t, mesh_t>();
	scene.shape_mesh_bank[SPHERE] = mesh_shape_init(SPHERE); 
	scene.shape_mesh_bank[BOX] = mesh_shape_init(BOX); 
	scene.shape_mesh_bank[LINE] = mesh_shape_init(LINE); 

	scene.transforms = new transform_t[max_entities];
	scene.colliders = new collider_t[max_entities];
	scene.renderers = new renderer_t[max_entities];
	scene.gizmos = new renderer_t[max_entities];

	scene.max_entities = max_entities;
	scene.n_entities = 0;
	scene.bookmark = 0;

	return scene;
}

void scene_erase(scene_t& scene, bool strong=true)
{
	scene.bookmark = strong ? 0 : scene.bookmark;
	scene.n_entities = scene.bookmark;
}

void scene_dispose(scene_t& scene)
{
	for
	(
		auto i = scene.shape_mesh_bank.begin();
		i != scene.shape_mesh_bank.end();
		i++
	)
	{ mesh_dispose(i->second); }

	for(int i = 0; i < scene.n_entities; i++)
	{ collider_dispose(scene.colliders[i]); }

	delete[] scene.transforms;
	delete[] scene.colliders;
	delete[] scene.renderers;
	delete[] scene.gizmos;
}

int add_entity(scene_t& scene, transform_t transform, collider_t collider, renderer_t renderer)
{
	if(scene.n_entities == scene.max_entities)
	{ return -1; }

	int idx = scene.n_entities;
	scene.transforms[idx] = transform;
	scene.colliders[idx] = collider;
	scene.renderers[idx] = renderer;
	scene.gizmos[idx] = renderer_init();
	scene.n_entities++;

	return idx;
}

void remove_entity(scene_t& scene, int idx)
{
	if(idx < 0 || idx >= scene.n_entities)
	{ return; }
	if(idx == scene.n_entities-1)
	{ scene.n_entities--; return; }

	int last = scene.n_entities-1;
	scene.transforms[idx] = scene.transforms[last];
	scene.colliders[idx] = scene.colliders[last];
	scene.renderers[idx] = scene.renderers[last];
	scene.gizmos[idx] = scene.gizmos[last];
	scene.n_entities--;
}

void toggle_gizmo(scene_t& scene, int idx, bool toggle)
{
	if(toggle)
	{
		collider_t col = scene.colliders[idx];
		mesh_t col_mesh = scene.shape_mesh_bank[col.type];
		renderer_t col_rend = renderer_init(col_mesh, scene.shader_bank["line"], scene.texture_bank["none"]);
		col_rend.modifier = make_model(col);
		col_rend.colour = glm::vec4(0,1,0,1);
		scene.gizmos[idx] = col_rend;
	}
	scene.gizmos[idx].enabled = toggle;
}

