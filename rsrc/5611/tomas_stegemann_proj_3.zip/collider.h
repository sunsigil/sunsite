#pragma once

#include <string>
#include <iostream>

#include <glm/glm.hpp>
#include <glm/gtx/norm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtx/string_cast.hpp>

enum shape_type_t
{
	SPHERE,
	BOX,
	LINE,

};

struct sphere_t
{
	glm::vec3 c;
	float r;
};

sphere_t sphere_init(glm::vec3 c, float r)
{ return (sphere_t) {c, r}; }

struct box_t
{
	glm::vec3 min;
	glm::vec3 max;
};

box_t box_init(glm::vec3 min, glm::vec3 max)
{ return (box_t) {min, max}; }

struct line_t
{
	glm::vec3 a;
	glm::vec3 b;
};

line_t line_init(glm::vec3 a, glm::vec3 b)
{ return (line_t) {a, b}; }

struct collider_t
{
	bool enabled;

	shape_type_t type;
	void* geometry;

	bool _static;
};

collider_t collider_init()
{
	collider_t collider;
	collider.enabled = false;
	return collider;
}

collider_t collider_sphere_init(sphere_t sphere)
{
	collider_t collider;
	collider.enabled = true;
	collider.type = SPHERE;
	sphere.c = glm::vec3(0);
	collider.geometry = malloc(sizeof(sphere));
	memcpy(collider.geometry, &sphere, sizeof(sphere));
	collider._static = false;
	return collider;
}

collider_t collider_box_init(box_t box)
{
	collider_t collider;
	collider.enabled = true;
	collider.type = BOX;
	glm::vec3 dims = box.max - box.min;
	box.min = dims * -0.5f;
	box.max = dims * 0.5f;
	collider.geometry = malloc(sizeof(box));
	memcpy(collider.geometry, &box, sizeof(box));
	collider._static = false;
	return collider;
}

collider_t collider_line_init(line_t line)
{
	collider_t collider;
	collider.enabled = true;
	collider.type = LINE;
	glm::vec3 mid = (line.a + line.b) * 0.5f;
	line.a -= mid;
	line.b -= mid;
	collider.geometry = malloc(sizeof(line));
	memcpy(collider.geometry, &line, sizeof(line));
	collider._static = false;
	return collider;
}

void collider_dispose(collider_t& collider)
{
	if(collider.geometry != nullptr)
	{ free(collider.geometry); }
}

glm::mat4 make_model(collider_t& collider)
{
	glm::mat4 T = glm::mat4(1);
	if(collider.type == SPHERE)
	{
		sphere_t* sphere = (sphere_t*) collider.geometry;
		T = glm::scale(glm::vec3(sphere->r));
	}
	else if(collider.type == BOX)
	{
		box_t* box = (box_t*) collider.geometry;
		glm::vec3 dims = box->max - box->min;
		T = glm::scale(dims);
	}
	else if(collider.type == LINE)
	{
		line_t* line = (line_t*) collider.geometry;
		glm::vec3 ref = glm::vec3(1, 0, 0);
		glm::vec3 skew = line->b - line->a;
		float scale = glm::length(skew);
		glm::mat4 scaling = glm::scale(glm::vec3(scale));
		float align = glm::dot(ref, skew);
		if(fabs(align) == 1)
		{ return scaling; }
		float angle = glm::acos(align);
		glm::vec3 axis = glm::normalize(glm::cross(ref, skew));
		glm::mat4 rotating = glm::rotate(angle, axis);
		T = rotating * scaling;
	}
	return T;
}
