#pragma once

#include <vector>
#include <list>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_access.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "scene.h"

struct ik_joint_t
{
	glm::vec3 center;
	struct ik_rod_t* b_rod;
	std::vector<struct ik_rod_t*> f_rods;
	int entity_idx;
};

struct ik_rod_t
{
	float angle;
	glm::vec3 tip;
	struct ik_joint_t* parent;
	struct ik_joint_t* child;
	int entity_idx;
};

ik_joint_t* ik_joint_init()
{
	ik_joint_t* joint = (ik_joint_t*) malloc(sizeof(ik_joint_t));
	joint->center = glm::vec3(0);
	joint->b_rod = nullptr;
	joint->f_rods = std::vector<ik_rod_t*>();
	joint->entity_idx = -1;
	return joint;
}

ik_rod_t* ik_rod_init()
{
	ik_rod_t* rod = (ik_rod_t*) malloc(sizeof(ik_rod_t));
	rod->angle = 0;
	rod->tip = glm::vec3(0);
	rod->parent = nullptr;
	rod->child = nullptr;
	rod->entity_idx = -1;
	return rod;
}

ik_rod_t* ik_get_free_rod(ik_joint_t* joint)
{
	if(joint == nullptr)
	{ return nullptr; }

	for(ik_rod_t* rod : joint->f_rods)
	{
		if(rod->child == nullptr)
		{ return rod; }
	}
	return nullptr;
}

ik_rod_t* ik_affix_rod(ik_joint_t* joint)
{
	if(joint == nullptr)
	{ return nullptr; }

	ik_rod_t* rod = ik_rod_init();
	rod->parent = joint;
	joint->f_rods.push_back(rod);
	return rod;
}

ik_joint_t* ik_affix_joint(ik_joint_t* joint)
{
	if(joint == nullptr)
	{ return nullptr; }

	ik_rod_t* rod = ik_get_free_rod(joint);
	if(rod == nullptr)
	{ return nullptr; }

	ik_joint_t* child = ik_joint_init();
	rod->child = child;
	child->b_rod = rod;
	return child;
}

ik_joint_t* ik_tree_init(glm::vec3 position)
{
	ik_joint_t* root = ik_joint_init();
	root->center = position;
	return root;
}

void ik_forward(ik_joint_t* joint, float angle)
{
	if(joint == nullptr)
	{ return; }

	if(joint->b_rod != nullptr)
	{ joint->center = joint->b_rod->tip; }

	for(ik_rod_t* rod : joint->f_rods)
	{
		float acc_angle = angle + rod->angle;
		glm::vec3 heading = glm::vec3(glm::cos(acc_angle), glm::sin(acc_angle), 0);
		rod->tip = joint->center + heading;
		ik_forward(rod->child, acc_angle);
	}
}

void ik_backward(ik_joint_t* root, ik_rod_t* rod, ik_rod_t* tip, glm::vec3 target, bool clamp_angles)
{
	if(root == nullptr || rod == nullptr)
	{ return; }

	ik_joint_t* joint = rod->parent;
	glm::vec3 start = joint->center;

	glm::vec3 target_heading = target - start;
	if(root == rod->parent && glm::length(target_heading) < 10e-3)
	{ return; }
	glm::vec3 tip_heading = tip->tip - start;

	float align = glm::dot(glm::normalize(target_heading), glm::normalize(tip_heading));
	align = clamp(align, -1, 1);
	float angle_diff = glm::acos(align);
	glm::vec3 axle = glm::cross(target_heading, tip_heading);

	if(axle.z < 0)
	{ rod->angle += angle_diff; }
	else
	{ rod->angle -= angle_diff; }
	if(clamp_angles)
	{ rod->angle = clamp(rod->angle, 0, M_PI * 0.5f); }
	
	ik_forward(root, 0);
	ik_backward(root, joint->b_rod, tip, target, clamp_angles);
}

void ik_gather_leaves(ik_joint_t* root, std::vector<ik_rod_t*>& leaves)
{
	if(root == nullptr)
	{ return; }

	for(ik_rod_t* rod : root->f_rods)
	{
		if(rod->child == nullptr)
		{ leaves.push_back(rod); }
		else
		{ ik_gather_leaves(rod->child, leaves); }
	}
}

void ik_tree_solve(ik_joint_t* root, glm::vec3 target, bool clamp_angles)
{
	ik_forward(root, 0);

	std::vector<ik_rod_t*> leaves = std::vector<ik_rod_t*>();
	ik_gather_leaves(root, leaves);
	ik_rod_t* nearest = leaves.front();
	for(ik_rod_t* leaf : leaves)
	{
		if(glm::length2(target - leaf->tip) < glm::length2(target - nearest->tip))
		{ nearest = leaf; }
	}

	ik_backward(root, nearest, nearest, target, clamp_angles);
}

void ik_mesh_spawn(scene_t& scene, ik_joint_t* joint, int depth)
{
	if(joint == nullptr)
	{ return; }

	transform_t transform = transform_init(joint->center);
	sphere_t ball = sphere_init(glm::vec3(0), 0.15f + 0.15f / (float) (depth+1));
	collider_t collider = collider_sphere_init(ball);
	int idx = add_entity(scene, transform, collider, renderer_init());
	toggle_gizmo(scene, idx, true);
	if(joint->b_rod == nullptr)
	{ scene.gizmos[idx].colour = glm::vec4(0.937, 0.463, 0.478, 1); }
	else
	{ scene.gizmos[idx].colour = glm::vec4(0.541, 0.353, 0.2, 1); }
	joint->entity_idx = idx;

	for(ik_rod_t* rod : joint->f_rods)
	{
		transform = transform_init(joint->center);
		line_t line = line_init(glm::vec3(0), glm::vec3(1,0,0));
		collider = collider_line_init(line);
		idx = add_entity(scene, transform, collider, renderer_init());
		toggle_gizmo(scene, idx, true);
		if(rod->child == nullptr)
		{ scene.gizmos[idx].colour = glm::vec4(0.412, 0.788, 0.373, 1); }
		else
		{ scene.gizmos[idx].colour = glm::vec4(0.541, 0.353, 0.2, 1); }
		rod->entity_idx = idx;

		ik_mesh_spawn(scene, rod->child, depth+1);
	}
}

void ik_mesh_pose(scene_t& scene, ik_joint_t* joint, float angle)
{
	if(joint == nullptr)
	{ return; }

	transform_t* joint_transform = scene.transforms+joint->entity_idx;
	joint_transform->position = joint->center;
	float avg_angle = 0; 

	for(ik_rod_t* rod : joint->f_rods)
	{
		transform_t* rod_transform = scene.transforms+rod->entity_idx;
		float acc_angle = angle + rod->angle;
		avg_angle += acc_angle;
		glm::vec3 heading = glm::vec3(glm::cos(acc_angle), glm::sin(acc_angle), 0);
		rod_transform->position = joint->center + heading * 0.5f;
		rod_transform->orientation = glm::quat(glm::vec3(0,0,acc_angle));

		ik_mesh_pose(scene, rod->child, acc_angle);
	}

	avg_angle /= joint->f_rods.size();
	joint_transform->orientation = glm::quat(glm::vec3(0,0,avg_angle));
}

void ik_tree_dispose(ik_joint_t* joint)
{
	if(joint == nullptr)
	{ return; }

	for(ik_rod_t* rod : joint->f_rods)
	{
		ik_tree_dispose(rod->child);
		free(rod);
	}

	free(joint);
}
