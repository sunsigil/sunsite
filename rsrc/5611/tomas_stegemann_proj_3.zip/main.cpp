#include <iostream>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <float.h>
#include <chrono>
#include <time.h>
#include <filesystem>
#include <map>
#include <list>

#include <GL/glew.h> 
#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>

#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/string_cast.hpp>

#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include "misc/cpp/imgui_stdlib.h"

#include "collision.h"
#include "mesh.h"
#include "shader.h"
#include "scene.h"
#include "window.h"
#include "cowtools.h"
#include "camera.h"
#include "assets.h"
#include "cloth.h"
#include "gui.h"
#include "ik_tree.h"

#define N_ROWS 30
#define N_COLS 30
#define LEN 1.0f

namespace fsys = std::filesystem;

void render_scene(scene_t& scene, window_t& window, camera_t& camera)
{
	for(int i = 0; i < scene.n_entities; i++)
	{
		if(scene.renderers[i].enabled)
		{ render(scene.renderers[i], scene.transforms[i], camera); }
		if(scene.gizmos[i].enabled)
		{ render(scene.gizmos[i], scene.transforms[i], camera); }
	}
}

int main(int argc, char** argv) 
{
	srand(time(NULL));

	// INIT WINDOW
	window_t window = window_init("Engine", glm::ivec2(1280, 720));
	gui_state_t gui_state;
	std::cerr << "initialized window" << std::endl;

	// INIT SCENE
	scene_t scene = scene_init(10000);
	
	int sky =
	add_entity
	(
		scene, transform_init(glm::vec3(0)), collider_init(),
		renderer_init(scene.mesh_bank["sky"], scene.shader_bank["sky"], scene.texture_bank["none"])
	);
	scene.renderers[sky].enabled = false;

	mesh_t grid_mesh = mesh_plane_init(glm::mat3(1));
	int grid =
	add_entity
	(
		scene, transform_init(glm::vec3(0)), collider_init(),
		renderer_init(grid_mesh, scene.shader_bank["grid"], scene.texture_bank["none"])
	);
	scene.renderers[grid].enabled = false;
	
	ik_joint_t* ik_root = ik_tree_init(glm::vec3(0)); // Stem joint 0 (root)
	ik_rod_t* ik_stem = ik_affix_rod(ik_root);
	ik_joint_t* ik_bulb = ik_affix_joint(ik_root); // Stem joint 1
	ik_stem = ik_affix_rod(ik_bulb);
	ik_bulb = ik_affix_joint(ik_bulb); // Stem joint 2
	ik_stem = ik_affix_rod(ik_bulb);
	ik_joint_t* ik_crux = ik_affix_joint(ik_bulb); // Stem joint 3 (crux)
	ik_stem = ik_affix_rod(ik_crux);
	ik_bulb = ik_affix_joint(ik_crux); // Left joint 0
	ik_stem = ik_affix_rod(ik_bulb);
	ik_bulb = ik_affix_joint(ik_bulb); // Left joint 1
	ik_stem = ik_affix_rod(ik_bulb);
	ik_bulb = ik_affix_joint(ik_bulb); // Left joint 2
	ik_stem = ik_affix_rod(ik_bulb); // End effector 0
	ik_stem = ik_affix_rod(ik_crux);
	ik_bulb = ik_affix_joint(ik_crux); // Right joint 0
	ik_stem = ik_affix_rod(ik_bulb);
	ik_bulb = ik_affix_joint(ik_bulb); // Right joint 1
	ik_stem = ik_affix_rod(ik_bulb);
	ik_bulb = ik_affix_joint(ik_bulb); // Right joint 2
	ik_stem = ik_affix_rod(ik_bulb); // End effector 1
	ik_mesh_spawn(scene, ik_root, 0);

	int target = add_entity
	(
		scene, transform_init(glm::vec3(0)), collider_init(),
		renderer_init(scene.mesh_bank["sphere"], scene.shader_bank["mesh"], scene.texture_bank["uv"])
	);
	scene.transforms[target].scale = glm::vec3(0.125f);
	scene.bookmark = target+1;
	
	camera_t camera = camera_init
	(
		transform_init(glm::vec3(0,0,-1)),
		M_PI/2,
		window.dimensions.x / (float) window.dimensions.y,
		0.1f, 1000.0f
	);
	std::cerr << "initialized scene" << std::endl;
	
	// CONFIGURE LOOP
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	std::chrono::time_point<std::chrono::system_clock> ft_last = std::chrono::system_clock::now();
	std::chrono::time_point<std::chrono::system_clock> ft = std::chrono::system_clock::now();
	std::chrono::duration<float> dft;

	bool esc_pressed = false;
	bool shift_pressed = false;
	bool f_pressed = false;
	bool e_pressed = false;
	window.paused = true;

	// ENGINE GO!
	while(!glfwWindowShouldClose(window.handle))
	{
		// TIMING
		ft = std::chrono::system_clock::now();
		dft = ft - ft_last;
		ft_last = ft;
		float dt = dft.count();
		
		// INPUT
		glfwPollEvents();
		
		if(glfwGetKey(window.handle, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		{
			if(!esc_pressed)
			{
				esc_pressed = true;
				window.paused = !window.paused;
			}
		}
		else
		{ esc_pressed = false; }
		if(glfwGetKey(window.handle, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS)
		{
			if(!shift_pressed)
			{ shift_pressed = true; }
		}
		else
		{ shift_pressed = false; }
		if(glfwGetKey(window.handle, GLFW_KEY_F) == GLFW_PRESS)
		{
			if(!f_pressed)
			{ f_pressed = true; }
		}
		else
		{ f_pressed = false; }
		if(glfwGetKey(window.handle, GLFW_KEY_E) == GLFW_PRESS)
		{
			if(!e_pressed)
			{ e_pressed = true; }
		}
		else
		{ e_pressed = false; }

		glfwSetInputMode(window.handle, GLFW_CURSOR, window.paused ? GLFW_CURSOR_NORMAL : GLFW_CURSOR_DISABLED); 
		
		if(!window.paused)
		{
			glm::vec3 forward = make_forward(camera.transform);
			glm::vec3 right = make_right(camera.transform);
			glm::vec3 z = glm::vec3(0,0,1);
			glm::vec3 x = glm::vec3(1,0,0);
			
			float fz_align = glm::dot(forward, z);
			float fx_align = glm::dot(forward, x);
			if(fabs(fz_align) > fabs(fx_align))
			{
				if(fz_align < 0)
				{ z *= -1; }
			}
			else if(fabs(fx_align) > fz_align)
			{
				z = glm::vec3(1,0,0);
				if(fx_align < 0)
				{ z *= -1; }
			}
			x = glm::normalize(glm::cross(glm::vec3(0,1,0), z));

			glm::vec3 wasd = glm::vec3(0,0,0);
			glm::vec3 arrows = glm::vec3(0,0,0);

			if(glfwGetKey(window.handle, GLFW_KEY_W) == GLFW_PRESS)
			{ wasd += forward; }
			if(glfwGetKey(window.handle, GLFW_KEY_A) == GLFW_PRESS)
			{ wasd += right; }
			if(glfwGetKey(window.handle, GLFW_KEY_S) == GLFW_PRESS)
			{ wasd -= forward; }
			if(glfwGetKey(window.handle, GLFW_KEY_D) == GLFW_PRESS)
			{ wasd -= right; }
			wasd = glm::length(wasd) > 0.0f ? glm::normalize(wasd) : wasd;
			camera.transform.velocity = wasd * (shift_pressed ? 20.0f : 10.0f);

			if(glfwGetKey(window.handle, GLFW_KEY_UP) == GLFW_PRESS)
			{ arrows += z; }
			if(glfwGetKey(window.handle, GLFW_KEY_LEFT) == GLFW_PRESS)
			{ arrows += x; }
			if(glfwGetKey(window.handle, GLFW_KEY_DOWN) == GLFW_PRESS)
			{ arrows -= z; }
			if(glfwGetKey(window.handle, GLFW_KEY_RIGHT) == GLFW_PRESS)
			{ arrows -= x; }
			arrows = glm::length(arrows) > 0.0f ? glm::normalize(arrows) : arrows;
			ik_root->center += arrows * 5.0f * dt;
			scene.transforms[target].position.z = ik_root->center.z;	

			glm::vec2 cursor = get_mouse_pos(window); 
			camera.transform.orientation = glm::quat(glm::vec3(-cursor.y, -cursor.x, 0));

			if(f_pressed)
			{
				hit_t z_hit;
				if(test_ray_plane(
					camera.transform.position, make_forward(camera.transform),
					glm::vec3(0,0,ik_root->center.z), glm::vec3(0,0,1),
					z_hit
				))
				{ scene.transforms[target].position = z_hit.position; }
			}
		}

		// PHYSICS
		if(!window.paused)
		{
			ik_tree_solve(ik_root, scene.transforms[target].position, gui_state.clamp_arm);
			ik_mesh_pose(scene, ik_root, 0);
			euler_integrate(camera.transform, dt);
		}

		// DRAWING
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		glDepthMask(GL_FALSE);
		render(scene.renderers[sky], scene.transforms[sky], camera);
		glDepthMask(GL_TRUE);

		render_scene(scene, window, camera);
		render(scene.renderers[grid], scene.transforms[grid], camera);
		render_gui(gui_state, window, scene, camera, dt);

		glfwSwapBuffers(window.handle);
	}

	// SCENE CLEANUP
	ik_tree_dispose(ik_root);
	scene_erase(scene);
	scene_dispose(scene);
	std::cerr << "disposed of scene" << std::endl;

	// CONTEXT CLEANUP
	window_dispose(window);
	std::cerr << "disposed of window" << std::endl;

  	return 0;
}
