#pragma once

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtx/quaternion.hpp>

#include "transform.h"

struct camera_t
{
	transform_t transform;
	float fov;
	float aspect;
	float near;
	float far;
	glm::mat4 proj;
};

camera_t camera_init(transform_t transform, float fov, float aspect, float near, float far)
{
	camera_t cam;
	cam.transform = transform;
	cam.fov = fov;
	cam.aspect = aspect;
	cam.near = near;
	cam.far = far;
	cam.proj = glm::perspective(fov, aspect, near, far);
	return cam;
}

glm::mat4 make_view(camera_t& camera)
{
	glm::vec3 eye = camera.transform.position;
	glm::vec3 forward = camera.transform.orientation * glm::vec3(0,0,1);
	glm::vec3 center = eye + forward;
	glm::vec3 up = camera.transform.orientation * glm::vec3(0,1,0);
	return glm::lookAt(eye, center, up);
}

glm::vec3 make_ray(camera_t& camera, glm::vec2 screen)
{
	glm::mat4 PV_inv = glm::inverse(camera.proj * make_view(camera));
	glm::vec4 near_pos = PV_inv * glm::vec4(screen.x, screen.y, -1.0f, 1.0f);
	near_pos /= near_pos.w;
	glm::vec4 far_pos = PV_inv * glm::vec4(screen.x, screen.y, 1.0f, 1.0f);
	far_pos /= far_pos.w;
	glm::vec3 dir = glm::normalize(glm::vec3(far_pos - near_pos));
	return glm::normalize(dir);
}

