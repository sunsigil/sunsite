#pragma once

#include <vector>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_access.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "scene.h"

struct arm_t
{
	int n_joints;

	glm::vec3 anchor;
	float* lengths;
	float* angles;
	float* clamps;
	glm::vec3 tip;

	int* joint_indices;
	int* rod_indices;
};

arm_t arm_init(int n_joints, glm::vec3 anchor)
{
	arm_t arm;
	arm.n_joints = n_joints;
	arm.anchor = anchor;
	arm.lengths = (float*) malloc(sizeof(float) * n_joints);
	arm.angles = (float*) malloc(sizeof(float) * n_joints);
	arm.clamps = (float*) malloc(sizeof(float) * n_joints);
	arm.joint_indices = (int*) malloc(sizeof(int) * arm.n_joints);
	arm.rod_indices = (int*) malloc(sizeof(int) * arm.n_joints);
	for(int i = 0; i < n_joints; i++)
	{
		arm.lengths[i] = 1;
		arm.angles[i] = 0;
		arm.clamps[i] = M_PI * 0.5f;
		arm.joint_indices[i] = -1;
		arm.rod_indices[i] = -1;
	}
	return arm;
}

void arm_spawn(scene_t& scene, arm_t& arm)
{
	for(int i = 0; i < arm.n_joints; i++)
	{
		transform_t transform = transform_init(arm.anchor);
		sphere_t ball = sphere_init(glm::vec3(0), 0.015f + 0.2f / (i+1));
		collider_t joint_collider = collider_sphere_init(ball);
		arm.joint_indices[i] = add_entity(scene, transform, joint_collider, renderer_init());
		toggle_gizmo(scene, arm.joint_indices[i], true);
		line_t stick = line_init(glm::vec3(0), glm::vec3(arm.lengths[i],0,0));
		collider_t rod_collider = collider_line_init(stick);
		arm.rod_indices[i] = add_entity(scene, transform, rod_collider, renderer_init());
		toggle_gizmo(scene, arm.rod_indices[i], true);
	}
}

void arm_forward(scene_t& scene, arm_t& arm)
{
	glm::vec3 pos = arm.anchor;
	float angle = 0;
	for(int i = 0; i < arm.n_joints; i++)
	{
		transform_t* joint = scene.transforms+arm.joint_indices[i];
		transform_t* rod = scene.transforms+arm.rod_indices[i];
		joint->position = pos;
		angle += arm.angles[i];
		glm::vec3 last_pos = pos;
		pos += arm.lengths[i] * glm::vec3(glm::cos(angle), glm::sin(angle), 0);
		rod->position = (last_pos + pos) * 0.5f;
		rod->orientation = glm::quat(glm::vec3(0,0, angle));
		joint->orientation = rod->orientation;
	}
	arm.tip = pos;
}

void arm_solve(scene_t& scene, arm_t& arm, glm::vec3 target, bool apply_clamps)
{
	arm_forward(scene, arm);

	for(int i = arm.n_joints-1; i >= 0; i--)
	{
		transform_t* joint = scene.transforms+arm.joint_indices[i];
		glm::vec3 start = joint->position;

		glm::vec3 target_heading = target - start;
		if(i == 0 && glm::length(target_heading) < 10e-6)
		{ continue; }
		glm::vec3 tip_heading = arm.tip - start;

		float align = glm::dot(glm::normalize(target_heading), glm::normalize(tip_heading));
		align = clamp(align, -1, 1);
		float angle_diff = glm::acos(align);

		glm::vec3 axle = glm::cross(target_heading, tip_heading);
		if(axle.z < 0)
		{ arm.angles[i] += angle_diff; }
		else
		{ arm.angles[i] -= angle_diff; }
		if(apply_clamps)
		{ arm.angles[i] = clamp(arm.angles[i], 0, arm.clamps[i]); }

		arm_forward(scene, arm);
	}
}

