#pragma once

#include <stdlib.h>
#include <math.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <filesystem>
#include <string_view>
#include <sstream>

#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>
#include <GL/glew.h> 

#include <glm/glm.hpp>
#include <glm/gtc/matrix_access.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "mesh.h"
#include "shader.h"
#include "texture.h"
#include "transform.h"
#include "camera.h"

struct renderer_t
{
	bool enabled;

	mesh_t mesh;

	shader_t shader;
	texture_t texture;

	glm::vec4 colour;
	glm::mat4 modifier;
	bool transparent;
};

renderer_t renderer_init()
{
	renderer_t renderer;
	renderer.enabled = false;
	return renderer;
}

renderer_t renderer_init(mesh_t mesh, shader_t shader, texture_t texture)
{
	renderer_t renderer;
	renderer.enabled = true;
	renderer.mesh = mesh;
	renderer.shader = shader;
	renderer.texture = texture;
	renderer.colour = glm::vec4(1);
	renderer.modifier = glm::mat4(1);
	renderer.transparent = false;
	return renderer;
}

void set_float_uniform(shader_t shader, std::string name, float value)
{
	GLint loc = glGetUniformLocation(shader.prog_id, name.c_str());
	if(loc != -1)
	{ glProgramUniform1f(shader.prog_id, loc, value); }
}

void set_vec4_uniform(shader_t shader, std::string name, glm::vec4 value)
{
	GLint loc = glGetUniformLocation(shader.prog_id, name.c_str());
	if(loc != -1)
	{ glProgramUniform4fv(shader.prog_id, loc, 1, glm::value_ptr(value)); }
}

void set_mat4_uniform(shader_t shader, std::string name, glm::mat4 value)
{
	GLint loc = glGetUniformLocation(shader.prog_id, name.c_str());
	if(loc != -1)
	{ glProgramUniformMatrix4fv(shader.prog_id, loc, 1, GL_FALSE, glm::value_ptr(value)); }
}

void set_tex2_uniform(shader_t shader, std::string name, int n, texture_t value)
{
	GLint loc = glGetUniformLocation(shader.prog_id, name.c_str());
	if(loc != -1)
	{
		glProgramUniform1i(shader.prog_id, loc, n);
		glActiveTexture(GL_TEXTURE0+n);
		glBindTexture(GL_TEXTURE_2D, value.tex_id);
	}
}

void set_texcube_uniform(shader_t shader, std::string name, int n, texture_t value)
{
	GLint loc = glGetUniformLocation(shader.prog_id, name.c_str());
	if(loc != -1)
	{
		glProgramUniform1i(shader.prog_id, loc, n);
		glActiveTexture(GL_TEXTURE0+n);
		glBindTexture(GL_TEXTURE_CUBE_MAP, value.tex_id);
	}
}

void render
(
	renderer_t& renderer,
	transform_t& transform,
	camera_t& camera
)
{
	glUseProgram(renderer.shader.prog_id);
	glBindVertexArray(renderer.mesh.vao_id);

	set_mat4_uniform(renderer.shader, "T", renderer.modifier);
	set_mat4_uniform(renderer.shader, "M", make_model(transform));
	set_mat4_uniform(renderer.shader, "V", make_view(camera));
	set_mat4_uniform(renderer.shader, "P", camera.proj);
	set_mat4_uniform(renderer.shader, "L", glm::mat4(glm::mat3(make_view(camera))));

	if(renderer.texture.mode == GL_TEXTURE_2D)
	{ set_tex2_uniform(renderer.shader, "tex", 0, renderer.texture); }
	else if(renderer.texture.mode == GL_TEXTURE_CUBE_MAP)
	{ set_texcube_uniform(renderer.shader, "tex_cube", 1, renderer.texture); }
	set_vec4_uniform(renderer.shader, "colour", renderer.colour);

	set_float_uniform(renderer.shader, "near", camera.near);
	set_float_uniform(renderer.shader, "far", camera.near);
	set_vec4_uniform(renderer.shader, "cam_pos", glm::vec4(camera.transform.position, 1.0f));
	set_vec4_uniform(renderer.shader, "cam_dir", glm::vec4(make_forward(camera.transform), 0.0f));
	set_vec4_uniform(renderer.shader, "light_dir", glm::vec4(1,-1,1,0));

	glDrawArrays(renderer.mesh.mode, 0, renderer.mesh.verts.size());
	glBindVertexArray(0);
	glUseProgram(0);
}

