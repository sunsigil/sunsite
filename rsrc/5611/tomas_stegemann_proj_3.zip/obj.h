#pragma once

#include <stdlib.h>
#include <math.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <filesystem>
#include <string_view>
#include <sstream>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_access.hpp>
#include <glm/gtx/string_cast.hpp>

#include "cowtools.h"

namespace fsys = std::filesystem;

struct OBJ_t
{
	fsys::path path;
	size_t size;

	std::vector<glm::vec3> vs;
	std::vector<glm::vec2> vts;
	std::vector<glm::vec3> vns;
	std::vector<glm::mat3> fs;
};

OBJ_t OBJ_init(fsys::path path)
{
	OBJ_t obj;
	obj.path = path;
	obj.size = fsys::file_size(path);
	obj.vs = std::vector<glm::vec3>();
	obj.vts = std::vector<glm::vec2>();
	obj.vns = std::vector<glm::vec3>();
	obj.fs = std::vector<glm::mat3>();

	std::ifstream file = std::ifstream(path);
	std::stringstream buffer;
	buffer << file.rdbuf();
	file.close();

	std::string text = buffer.str();
	std::vector<std::string_view> lines = split(text, '\n');

	for(std::string_view line : lines)
	{
		std::vector<std::string_view> ltokens = split(line, ' ');
		if(ltokens[0] == "v")
		{
			obj.vs.push_back(glm::vec3(svtof(ltokens[1]), svtof(ltokens[2]), svtof(ltokens[3])));
		}
		else if(ltokens[0] == "vt")
		{
			obj.vts.push_back(glm::vec2(svtof(ltokens[1]), svtof(ltokens[2])));
		}
		else if(ltokens[0] == "vn")
		{
			obj.vns.push_back(glm::vec3(svtof(ltokens[1]), svtof(ltokens[2]), svtof(ltokens[3])));
		}
		else if(ltokens[0] == "f")
		{
			std::vector<std::string_view> atokens = split(ltokens[1], '/');
			std::vector<std::string_view> btokens = split(ltokens[2], '/');
			std::vector<std::string_view> ctokens = split(ltokens[3], '/');
			glm::vec3 a = glm::vec3(svtof(atokens[0]), svtof(atokens[1]), svtof(atokens[2]));
			glm::vec3 b = glm::vec3(svtof(btokens[0]), svtof(btokens[1]), svtof(btokens[2]));
			glm::vec3 c = glm::vec3(svtof(ctokens[0]), svtof(ctokens[1]), svtof(ctokens[2]));
			obj.fs.push_back(glm::mat3(a, b, c));
		}
	}

	return obj;
}
