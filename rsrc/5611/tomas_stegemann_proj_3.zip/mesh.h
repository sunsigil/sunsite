#pragma once

#include <stdlib.h>
#include <math.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <filesystem>
#include <string_view>
#include <sstream>

#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>
#include <GL/glew.h> 

#include <glm/glm.hpp>
#include <glm/gtc/matrix_access.hpp>
#include <glm/gtx/string_cast.hpp>

#include "obj.h"
#include "collider.h"

struct vertex_t
{
	glm::vec3 pos;
	glm::vec2 uv;
	glm::vec3 norm;
};

struct mesh_t
{
	GLuint vao_id;
	GLuint vbo_id;
	std::vector<vertex_t> verts;
	GLenum mode;
};

mesh_t mesh_init(std::vector<vertex_t> verts, GLenum mode)
{
	GLuint vao_id;
	glGenVertexArrays(1, &vao_id);
	glBindVertexArray(vao_id);

	GLuint vbo_id;
	glGenBuffers(1, &vbo_id);
	glBindBuffer(GL_ARRAY_BUFFER, vbo_id);
	glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(vertex_t), verts.data(), GL_STATIC_DRAW);
	
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(vertex_t), (void*) offsetof(vertex_t, pos));
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(vertex_t), (void*) offsetof(vertex_t, uv));
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(vertex_t), (void*) offsetof(vertex_t, norm));
	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
	glEnableVertexAttribArray(2);
	
	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	mesh_t mesh;
	mesh.vao_id = vao_id;
	mesh.vbo_id = vbo_id;
	mesh.verts = verts;
	mesh.mode = mode;

	return mesh;
}

void mesh_dispose(const mesh_t& mesh)
{
	if(mesh.verts.empty())
	{ return; }

	glDeleteVertexArrays(1, &mesh.vao_id);
	glDeleteBuffers(1, &mesh.vbo_id);
}

mesh_t mesh_OBJ_init(OBJ_t& obj)
{
	std::vector<vertex_t> verts = std::vector<vertex_t>();

	for(glm::mat3 f : obj.fs)
	{
		for(int i = 0; i < 3; i++)
		{
			glm::vec3 p = glm::column(f, i);

			glm::vec3 v = obj.vs[p[0]-1];
			glm::vec2 vt = obj.vts[p[1]-1];
			glm::vec3 vn = obj.vns[p[2]-1];

			verts.push_back({ v, vt, vn });
		}
	}

	return mesh_init(verts, GL_TRIANGLES);
}

mesh_t mesh_plane_init(glm::mat3 basis)
{
	glm::vec3 o = glm::vec3(0);
	glm::vec3 u = glm::normalize(glm::column(basis, 0));
	glm::vec3 v = glm::normalize(glm::column(basis, 1));
	glm::vec3 w = glm::normalize(glm::column(basis, 2));

	glm::vec3 bl = o - u - v;
	glm::vec3 tl = o - u + v;
	glm::vec3 tr = o + u + v;
	glm::vec3 br = o + u - v;
	
	std::vector<vertex_t> verts = std::vector<vertex_t>();
	verts.push_back({bl, glm::vec2(0,0), w});
	verts.push_back({tr, glm::vec2(1,1), w});
	verts.push_back({tl, glm::vec2(0,1), w});
	verts.push_back({tr, glm::vec2(1,1), w});
	verts.push_back({bl, glm::vec2(0,0), w});
	verts.push_back({br, glm::vec2(1,0), w});
	return mesh_init(verts, GL_TRIANGLES);
}

mesh_t mesh_shape_init(shape_type_t type)
{
	std::vector<vertex_t> verts = std::vector<vertex_t>();

	if(type == SPHERE)
	{
		std::vector<glm::vec3> x_ring = make_ring(glm::vec3(1,0,0), 1, 16); 
		std::vector<glm::vec3> y_ring = make_ring(glm::vec3(0,1,0), 1, 16); 
		std::vector<glm::vec3> z_ring = make_ring(glm::vec3(0,0,1), 1, 16);
		for(int i = 0; i < 3; i++)
		{
			glm::vec3 axis = glm::vec3(); axis[i] = 1;
			std::vector<glm::vec3> ring = make_ring(axis, 1, 16);
			for(int i = 0; i < ring.size()-1; i++)
			{
				verts.push_back({ring[i], glm::vec2(), glm::vec3()});
				verts.push_back({ring[i+1], glm::vec2(), glm::vec3()});
			}
			verts.push_back({ring.back(), glm::vec2(), glm::vec3()});
			verts.push_back({ring[0], glm::vec2(), glm::vec3()});
		}
	}
	else if(type == BOX)
	{
		glm::vec3 min_x = glm::vec3(-0.5,0,0);
		glm::vec3 min_y = glm::vec3(0,-0.5,0);
		glm::vec3 min_z = glm::vec3(0,0,-0.5);
		glm::vec3 max_x = glm::vec3(-0.5,0,0);
		glm::vec3 max_y = glm::vec3(0,-0.5,0);
		glm::vec3 max_z = glm::vec3(0,0,-0.5);

		verts.push_back({min_x, glm::vec2(), glm::vec3()});
		verts.push_back({max_x, glm::vec2(), glm::vec3()});
		verts.push_back({min_y, glm::vec2(), glm::vec3()});
		verts.push_back({max_y, glm::vec2(), glm::vec3()});
		verts.push_back({min_y, glm::vec2(), glm::vec3()});
		verts.push_back({max_y, glm::vec2(), glm::vec3()});
	}
	else if(type == LINE)
	{
		glm::vec3 a = glm::vec3(-0.5, 0, 0);
		glm::vec3 b = glm::vec3(0.5, 0, 0);
		verts.push_back({a, glm::vec2(), glm::vec3()});
		verts.push_back({b, glm::vec2(), glm::vec3()});
	}

	return mesh_init(verts, GL_LINES);
}

