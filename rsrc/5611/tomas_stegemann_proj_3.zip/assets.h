#pragma once

#include <string>
#include <filesystem>
#include <map>

#include "shader.h"
#include "texture.h"
#include "mesh.h"

namespace fsys = std::filesystem;

std::map<std::string, shader_t> load_shaders(fsys::path dir)
{
	std::map<std::string, shader_t> bank = std::map<std::string, shader_t>();
	for(fsys::path file : fsys::directory_iterator(dir))
	{
		if
		(
			fsys::is_regular_file(file) &&
			file.extension() == ".vert"
		)
		{
			std::string vert_path = file;
			std::string frag_path = file.replace_extension(".frag");
			shader_t shader = load_shader(vert_path, frag_path);
			bank[file.stem()] = shader;
		}
	}
	return bank;
}

void unload_shaders(std::map<std::string, shader_t> bank)
{
	for(std::map<std::string, shader_t>::const_iterator i = bank.begin(); i != bank.end(); i++)
	{ shader_dispose(i->second); }
}

std::map<std::string, texture_t> load_textures(fsys::path dir)
{
	std::map<std::string, texture_t> bank = std::map<std::string, texture_t>();
	for(fsys::path file : fsys::directory_iterator(dir))
	{
		if
		(
			fsys::is_regular_file(file) &&
			file.extension() == ".png"
		)
		{
			PNG_t png = PNG_init(file);
			texture_t texture = texture_PNG_init(png);
			bank[file.stem()] = texture;
		}
	}
	return bank;
}

void unload_textures(std::map<std::string, texture_t> bank)
{
	for(std::map<std::string, texture_t>::const_iterator i = bank.begin(); i != bank.end(); i++)
	{ texture_dispose(i->second); }
}

std::map<std::string, mesh_t> load_meshes(fsys::path dir)
{
	std::map<std::string, mesh_t> bank = std::map<std::string, mesh_t>();
	for(fsys::path file : fsys::directory_iterator(dir))
	{
		if
		(
			fsys::is_regular_file(file) &&
			file.extension() == ".obj"
		)
		{
			OBJ_t obj = OBJ_init(file);
			mesh_t mesh = mesh_OBJ_init(obj);
			bank[file.stem()] = mesh;
		}
	}
	return bank;
}

void unload_meshes(std::map<std::string, mesh_t> bank)
{
	for(std::map<std::string, mesh_t>::const_iterator i = bank.begin(); i != bank.end(); i++)
	{ mesh_dispose(i->second); }
}
