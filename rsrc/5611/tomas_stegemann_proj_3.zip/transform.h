#pragma once

#include <iostream>
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtx/quaternion.hpp>

struct transform_t
{
	bool enabled;

	glm::vec3 scale;
	glm::quat orientation;
	glm::vec3 position;
	glm::vec3 velocity;
	glm::vec3 acceleration;
};

transform_t transform_init()
{
	transform_t transform;
	transform.enabled = false;
	return transform;
}

transform_t transform_init(glm::vec3 position)
{
	transform_t transform;
	transform.enabled = true;
	transform.scale = glm::vec3(1,1,1);
	transform.orientation = glm::quat(glm::vec3(0,0,0));
	transform.position = position;
	transform.velocity = glm::vec3(0,0,0);
	transform.acceleration = glm::vec3(0,0,0);
	return transform;
}

glm::mat4 make_model(transform_t& transform)
{
	glm::mat4 S = glm::scale(transform.scale);
	glm::mat4 R = glm::toMat4(transform.orientation);
	glm::mat4 T = glm::translate(transform.position);
	return T*R*S;
}

glm::vec3 make_forward(transform_t& transform)
{ return transform.orientation * glm::vec3(0,0,1); }
glm::vec3 make_up(transform_t& transform)
{ return transform.orientation * glm::vec3(0,1,0); }
glm::vec3 make_right(transform_t& transform)
{ return transform.orientation * glm::vec3(1,0,0); }

void euler_integrate(transform_t& transform, float dt)
{
	transform.velocity += transform.acceleration * dt;
	transform.position += transform.velocity * dt;
}


