#pragma once

#define GLFW_INCLUDE_NONE
#define GLFW_EXPOSE_NATIVE_COCOA
#define GL_SILENCE_DEPRECATION

#include <iostream>
#include <string>
#include <cstring>

#include <GL/glew.h> 
#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>

#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include "misc/cpp/imgui_stdlib.h"

struct window_t
{
	glm::ivec2 dimensions;
	GLFWwindow* handle; 	
	ImGuiWindowFlags flags;

	std::string renderer_str;
	std::string version_str;

	glm::vec2 mouse_pos;
	bool paused;
};

window_t window_init(std::string name, glm::ivec2 dimensions)
{
	// Initialize IMGUI
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void) io;
	
	// Configure IMGUI
    ImGui::StyleColorsDark();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
	ImGuiWindowFlags flags =
	ImGuiWindowFlags_NoSavedSettings |
	ImGuiWindowFlags_NoMove |
	ImGuiWindowFlags_NoResize |
	ImGuiWindowFlags_NoSavedSettings |
	ImGuiWindowFlags_NoCollapse |
	ImGuiWindowFlags_NoTitleBar |
	ImGuiWindowFlags_NoBackground;
    
	if(!glfwInit()) 
	{
		std::cerr << "error: failed to initialize GLFW!" << std::endl;
		exit(EXIT_FAILURE);
	} 

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
  
	GLFWwindow* handle = glfwCreateWindow(dimensions.x, dimensions.y, name.c_str(), NULL, NULL);
	if(!handle) 
	{
		std::cerr << "error: failed to open GLFW window!" << std::endl;
		glfwTerminate();
		exit(EXIT_FAILURE);
	}
  	glfwMakeContextCurrent(handle);
	
	ImGui_ImplGlfw_InitForOpenGL(handle, true);
	ImGui_ImplOpenGL3_Init("#version 150");
								  
  	glewExperimental = GL_TRUE;
  	if(glewInit() != GLEW_OK)
	{
		std:: cerr << "error: failed to initialize GLEW!" << std::endl;
		glfwTerminate();
		exit(EXIT_FAILURE);
	}

	const GLubyte* renderer_glstr = glGetString(GL_RENDERER);
	const GLubyte* version_glstr = glGetString(GL_VERSION);
	char renderer_cstr[512];
	char version_cstr[512];
	strcpy(renderer_cstr, (const char*) renderer_glstr);
	strcpy(version_cstr, (const char*) version_glstr);

	window_t window;
	window.dimensions = dimensions;
	window.flags = flags;
	window.handle = handle;
  	window.renderer_str = std::string(renderer_cstr);
  	window.version_str = std::string(version_cstr);
	window.paused = false;
	return window;
}

void window_dispose(window_t& window)
{
	ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
	glfwDestroyWindow(window.handle);
  	glfwTerminate();
}

glm::vec2 get_mouse_pos(window_t& window)
{
	double x, y;
	glfwGetCursorPos(window.handle, &x, &y);
	x /= window.dimensions.x; y /= window.dimensions.y;
	return 2.0f * glm::vec2(x - 0.5f, 0.5f - y);
}

