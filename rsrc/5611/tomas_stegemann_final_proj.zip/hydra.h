#pragma once

#include <glm/glm.hpp>
#include <glm/gtc/matrix_access.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/random.hpp>

#include "scene.h"
#include "ik_tree.h"

ik_joint_t* spawn_hydra(scene_t& scene, int trunk_length, int neck_length, int neck_count)
{
	ik_joint_t* ik_root = ik_tree_init(glm::vec3(0));
	ik_joint_t* ik_trunk = ik_root;

	for(int i = 0; i < trunk_length; i++)
	{
		ik_affix_rod(ik_trunk);
		ik_trunk = ik_affix_joint(ik_trunk);
	}

	for(int i = 0; i < neck_count; i++)
	{
		ik_joint_t* ik_neck = ik_trunk;
		for(int j = 0; j < neck_length; j++)
		{
			ik_affix_rod(ik_neck);
			ik_neck = ik_affix_joint(ik_neck);
		}
		ik_affix_rod(ik_neck);
	}

	ik_mesh_spawn(scene, ik_root);

	return ik_root;
}

void target_hydra_old(ik_joint_t* root, glm::vec3 target, float radius)
{
	glm::vec3 center = root->center;
	glm::vec3 east = center + radius * glm::vec3(1,0,0);
	glm::vec3 heading = target - center;
	if(glm::length2(heading) > radius * radius)
	{ return; }

	float angle = glm::angle(east, heading);
	float start = angle + M_PI * 0.5f;

	std::vector<ik_rod_t*> leaves = std::vector<ik_rod_t*>();
	ik_gather_leaves(root, leaves);
	int n = leaves.size();
	float arc = 2 * M_PI / (n-1);

	int nearest_idx = 0;
	for(int i = 1; i < n; i++)
	{
		ik_rod_t* nearest = leaves[nearest_idx];
		ik_rod_t* candidate = leaves[i];
		glm::vec3 nearest_pos = nearest->parent->center + nearest->axis * ROD_LENGTH;
		nearest_pos.y = 0;
		glm::vec3 candidate_pos = candidate->parent->center + candidate->axis * ROD_LENGTH;
		candidate_pos.y = 0;
		float nearest_dist2 = glm::length2(nearest_pos - target);
		float candidate_dist2 = glm::length2(candidate_pos - target);
		if(candidate_dist2 < nearest_dist2)
		{ nearest_idx = i; }
	}

	float theta = start;
	ik_forward(root);
	for(int i = 0; i < n; i++)
	{
		if(i != nearest_idx)
		{
			theta += arc;
			glm::vec3 point = center + radius * glm::vec3(cos(theta), 0.5f, sin(theta));
			ik_backward(root, leaves[i], leaves[i], point);
		}
		else
		{
			ik_backward(root, leaves[i], leaves[i], target);
		}
	}
}

void target_hydra(ik_joint_t* root, glm::vec3 target, float radius)
{
	glm::vec3 center = root->center;
	glm::vec3 east = center + radius * glm::vec3(1,0,0);
	glm::vec3 heading = target - center;
	if(glm::length2(heading) > radius * radius)
	{ return; }

	float angle = glm::angle(east, heading);

	std::vector<ik_rod_t*> leaves = std::vector<ik_rod_t*>();
	ik_gather_leaves(root, leaves);
	int n = leaves.size();

	int nearest_idx = 0;
	for(int i = 0; i < n; i++)
	{
		float theta_a = i * (2 * M_PI / n);
		float theta_b = ((i + 1) % n) * (2 * M_PI / n);
		if(angle >= theta_a && angle < theta_b)
		{ nearest_idx = i; }
	}

	ik_forward(root);
	for(int i = 0; i < n; i++)
	{
		if(i != nearest_idx)
		{
			float theta = (i + 0.5f) * (2 * M_PI / n);
			glm::vec3 point = center + radius * glm::vec3(cos(theta), 0.5f, sin(theta));
			ik_backward(root, leaves[i], leaves[i], point);
		}
		else
		{
			ik_backward(root, leaves[i], leaves[i], target);
		}
	}
}
