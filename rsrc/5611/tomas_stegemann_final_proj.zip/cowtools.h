#pragma once

#include <string>
#include <vector>
#include <map>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_access.hpp>
#include <glm/gtx/string_cast.hpp>

float frand(float min, float max)
{
	float core = (float) rand() / (float) RAND_MAX;
	float range = max - min;
	return min + core * range;
}

float clamp(float v, float min, float max)
{
	if(v < min)
	{ return min; }
	if(v > max)
	{ return max; }
	return v;
}

std::vector<std::string> split(std::string strv, char delim)
{
	std::vector<std::string> tokens;
	for(std::string::iterator start = strv.begin(); start < strv.end(); start++)
	{
		std::string::iterator end = std::find(start, strv.end(), delim);
		tokens.push_back(std::string(start, end));
		start = end;
	}
	return tokens;
}

glm::mat3 normal_basis(glm::vec3 w)
{
	glm::vec3 u, v;

	if(w.x != 0)
	{ v = glm::vec3(-w.z/w.x, 0, 1); }
	else if(w.y != 0)
	{ v = glm::vec3(1, -w.x/w.y, 0); }
	else if(w.z != 0)
	{ v = glm::vec3(0, 1, -w.y/w.z); }

	u = glm::normalize(glm::cross(v, w)); 
	v = glm::normalize(glm::cross(w, u)); 

	return glm::mat3(u, v, w);
}

std::vector<glm::vec3> make_ring(glm::vec3 n, float r, int res)
{
	glm::mat3 basis = normal_basis(n);
	glm::vec3 u = glm::column(basis, 1);
	glm::vec3 v = glm::column(basis, 2);

	std::vector<glm::vec3> verts = std::vector<glm::vec3>();
	float arc = 2*M_PI / res;
	for(int i = 0; i < res; i++)
	{
		float t = arc * i;
		glm::vec3 p = r * (cos(t) * u + sin(t) * v);
		verts.push_back(p);
	}

	return verts;
}

template <typename T> std::vector<std::string> get_keys(std::map<std::string, T> map)
{
	std::vector<std::string> keys = std::vector<std::string>();
	for(typename std::map<std::string, T>::iterator i = map.begin(); i != map.end(); i++)
	{ keys.push_back(i->first); }
	return keys;
}
