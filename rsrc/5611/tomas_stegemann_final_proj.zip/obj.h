#pragma once

#include <stdlib.h>
#include <math.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <string_view>
#include <sstream>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_access.hpp>
#include <glm/gtx/string_cast.hpp>

#include "cowtools.h"

namespace fsys = std::filesystem;

struct OBJ_t
{
	fsys::path path;
	size_t size;

	std::vector<glm::vec3> vs;
	std::vector<glm::vec2> vts;
	std::vector<glm::vec3> vns;
	std::vector<glm::mat3> fs;
};

OBJ_t OBJ_init(fsys::path path)
{
	OBJ_t obj;
	obj.path = path;
	obj.size = fsys::file_size(path);
	obj.vs = std::vector<glm::vec3>();
	obj.vts = std::vector<glm::vec2>();
	obj.vns = std::vector<glm::vec3>();
	obj.fs = std::vector<glm::mat3>();

	std::ifstream file = std::ifstream(path);
	std::stringstream buffer;
	buffer << file.rdbuf();
	file.close();

	std::string text = buffer.str();
	std::vector<std::string> lines = split(text, '\n');

	for(std::string line : lines)
	{
		std::vector<std::string> ltokens = split(line, ' ');
		if(ltokens[0] == "v")
		{
			obj.vs.push_back(glm::vec3(stof(ltokens[1]), stof(ltokens[2]), stof(ltokens[3])));
		}
		else if(ltokens[0] == "vt")
		{
			obj.vts.push_back(glm::vec2(stof(ltokens[1]), stof(ltokens[2])));
		}
		else if(ltokens[0] == "vn")
		{
			obj.vns.push_back(glm::vec3(stof(ltokens[1]), stof(ltokens[2]), stof(ltokens[3])));
		}
		else if(ltokens[0] == "f")
		{
			std::vector<std::string> atokens = split(ltokens[1], '/');
			std::vector<std::string> btokens = split(ltokens[2], '/');
			std::vector<std::string> ctokens = split(ltokens[3], '/');
			glm::vec3 a = glm::vec3(stof(atokens[0]), stof(atokens[1]), stof(atokens[2]));
			glm::vec3 b = glm::vec3(stof(btokens[0]), stof(btokens[1]), stof(btokens[2]));
			glm::vec3 c = glm::vec3(stof(ctokens[0]), stof(ctokens[1]), stof(ctokens[2]));
			obj.fs.push_back(glm::mat3(a, b, c));
		}
	}

	return obj;
}
