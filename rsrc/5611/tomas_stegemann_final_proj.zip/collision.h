#pragma once

#include <stdlib.h>
#include <vector>

#include <glm/glm.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtx/projection.hpp>

#include "shape.h"
#include "transform.h"

struct collider_t
{
	bool enabled;

	shape_type_t type;
	void* geometry;

	bool _static;
};

struct hit_t
{
	glm::vec3 position;
	glm::vec3 normal;
};

collider_t collider_init()
{
	collider_t collider;
	collider.enabled = false;
	return collider;
}

collider_t collider_sphere_init(sphere_t sphere)
{
	collider_t collider;
	collider.enabled = true;
	collider.type = SPHERE;
	sphere.c = glm::vec3(0);
	collider.geometry = malloc(sizeof(sphere));
	memcpy(collider.geometry, &sphere, sizeof(sphere));
	collider._static = false;
	return collider;
}

collider_t collider_box_init(box_t box)
{
	collider_t collider;
	collider.enabled = true;
	collider.type = BOX;
	glm::vec3 dims = box.max - box.min;
	box.min = dims * -0.5f;
	box.max = dims * 0.5f;
	collider.geometry = malloc(sizeof(box));
	memcpy(collider.geometry, &box, sizeof(box));
	collider._static = false;
	return collider;
}

collider_t collider_line_init(line_t line)
{
	collider_t collider;
	collider.enabled = true;
	collider.type = LINE;
	glm::vec3 mid = (line.a + line.b) * 0.5f;
	line.a -= mid;
	line.b -= mid;
	collider.geometry = malloc(sizeof(line));
	memcpy(collider.geometry, &line, sizeof(line));
	collider._static = false;
	return collider;
}

void collider_dispose(collider_t& collider)
{
	if(collider.geometry != nullptr)
	{ free(collider.geometry); }
}

glm::mat4 collider_model(collider_t& collider)
{
	glm::mat4 T = glm::mat4(1);
	if(collider.type == SPHERE)
	{ T = sphere_model(*(sphere_t*) collider.geometry); }
	else if(collider.type == BOX)
	{ T = box_model(*(box_t*) collider.geometry); }
	else if(collider.type == LINE)
	{ T = line_model(*(line_t*) collider.geometry); }
	return T;
}

bool sphere_sphere(sphere_t& S1, sphere_t& S2)
{
	float span = S1.r+S2.r;
	return glm::length2(S2.c - S1.c) <= span*span;
}

float sq_dist_point_box(glm::vec3 p, glm::vec3 min, glm::vec3 max)
{
	float sq_dist = 0.0f;
	if(p.x < min.x)
	{ sq_dist += (min.x - p.x) * (min.x - p.x); }
	if(p.y < min.y)
	{ sq_dist += (min.y - p.y) * (min.y - p.y); }
	if(p.z < min.z)
	{ sq_dist += (min.z - p.z) * (min.z - p.z); }
	if(p.x > max.x)
	{ sq_dist += (p.x - max.x) * (p.x - max.x); }
	if(p.y > max.y)
	{ sq_dist += (p.y - max.y) * (p.y - max.y); }
	if(p.z > max.z)
	{ sq_dist += (p.z - max.z) * (p.z - max.z); }
	return sq_dist;
}

bool sphere_box(sphere_t& S, box_t& B)
{
	float sq_dist = sq_dist_point_box(S.c, B.min, B.max);
	return sq_dist <= S.r*S.r;
}

bool test_sphere_sphere(sphere_t& S1, sphere_t& S2, hit_t& hit)
{
	if(sphere_sphere(S1, S2))
	{
		glm::vec3 span = S1.c - S2.c;
		float dist = glm::length(span);
		hit.normal = dist > 0 ? span/dist : glm::vec3(0,1,0);
		hit.position = S2.c + hit.normal * S2.r;
		return true;
	}
	
	return false;
}

bool point_inside_box(glm::vec3 p, glm::vec3 min, glm::vec3 max)
{
	return
	p.x > min.x && p.x < max.x &&
	p.y > min.y && p.y < max.y &&
	p.z > min.z && p.z < max.z;
}

bool test_sphere_box(sphere_t& S, box_t& B, hit_t& hit)
{
	if(sphere_box(S, B))
	{
		if(point_inside_box(S.c, B.min, B.max))
		{
			glm::vec3 min_arms = S.c - B.min;
			glm::vec3 max_arms = B.max - S.c;
			float min_x_dist = fmin(min_arms.x, max_arms.x);
			float min_y_dist = fmin(min_arms.y, max_arms.y);
			float min_z_dist = fmin(min_arms.z, max_arms.z);
			float min_dist = fmin(fmin(min_x_dist, min_y_dist), min_z_dist);
			
			if(min_dist == min_arms.x)
			{ hit.position = glm::vec3(B.min.x, S.c.y, S.c.z); }
			else if(min_dist == min_arms.y)
			{ hit.position = glm::vec3(S.c.x, B.min.y, S.c.z); }
			else if(min_dist == min_arms.z)
			{ hit.position = glm::vec3(S.c.x, S.c.y, B.min.z); }
			else if(min_dist == max_arms.x)
			{ hit.position = glm::vec3(B.max.x, S.c.y, S.c.z); }
			else if(min_dist == max_arms.y)
			{ hit.position = glm::vec3(S.c.x, B.max.y, S.c.z); }
			else if(min_dist == max_arms.z)
			{ hit.position = glm::vec3(S.c.x, S.c.y, B.max.z); }

			hit.normal = glm::normalize(hit.position - S.c);
		}
		else
		{
			hit.position = glm::clamp(S.c, B.min, B.max);
			hit.normal = glm::normalize(S.c - hit.position);
		}

		return true;
	}

	return false;
}

bool test_sphere_line(sphere_t& S, line_t& L, hit_t& hit)
{
	glm::vec3 body = L.b - L.a;
	float length = glm::length(body);
	glm::vec3 dir = body / length;

	float b = 2 * glm::dot(dir, L.a - S.c);
	float c = glm::dot(L.a-S.c, L.a-S.c) - S.r*S.r;
	
	float t = (-b - sqrt(b*b - 4*c)) * 0.5f;
	if(t > 0.0f && t < length)
	{
		glm::vec3 arm = S.c - L.a;
		glm::vec3 point = L.a + glm::proj(arm, body);

		hit.position = point;
		hit.normal = glm::normalize(S.c - point);
		return true;
	}

	return false;
}

bool test_ray_plane(glm::vec3 o, glm::vec3 d, glm::vec3 p, glm::vec3 n, hit_t& hit)
{
	float denom = glm::dot(d, n);
	if(denom != 0)
	{
		float t = glm::dot((p - o), n) / denom;
		if(t >= 0)
		{
			hit.position = o + d * t;
			hit.normal = n;
			return true;
		}
	}
	return false;
}

