#pragma once

#include <vector>
#include <list>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_access.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/vector_angle.hpp>

#include "scene.h"

#define ROD_LENGTH 1.5f

struct ik_joint_t
{
	glm::vec3 center;

	struct ik_rod_t* parent;
	std::vector<struct ik_rod_t*> children;

	int entity_idx;
};

struct ik_rod_t
{
	glm::vec3 axis;
	glm::quat orientation;

	struct ik_joint_t* parent;
	struct ik_joint_t* child;

	int entity_idx;
};

ik_joint_t* ik_joint_init()
{
	ik_joint_t* joint = (ik_joint_t*) malloc(sizeof(ik_joint_t));

	joint->center = glm::vec3(0);
	joint->parent = nullptr;
	joint->children = std::vector<ik_rod_t*>();
	joint->entity_idx = -1;

	return joint;
}

ik_rod_t* ik_rod_init()
{
	ik_rod_t* rod = (ik_rod_t*) malloc(sizeof(ik_rod_t));

	rod->axis = glm::vec3(0,1,0);
	rod->orientation = glm::identity<glm::quat>();
	rod->parent = nullptr;
	rod->child = nullptr;
	rod->entity_idx = -1;

	return rod;
}

ik_rod_t* ik_get_free_rod(ik_joint_t* joint)
{
	if(joint == nullptr)
	{ return nullptr; }

	for(ik_rod_t* rod : joint->children)
	{
		if(rod->child == nullptr)
		{ return rod; }
	}

	return nullptr;
}

ik_rod_t* ik_affix_rod(ik_joint_t* joint)
{
	if(joint == nullptr)
	{ return nullptr; }

	ik_rod_t* rod = ik_rod_init();
	rod->parent = joint;
	joint->children.push_back(rod);

	return rod;
}

ik_joint_t* ik_affix_joint(ik_joint_t* joint)
{
	if(joint == nullptr)
	{ return nullptr; }

	ik_rod_t* rod = ik_get_free_rod(joint);
	if(rod == nullptr)
	{ return nullptr; }

	ik_joint_t* child = ik_joint_init();
	rod->child = child;
	child->parent = rod;

	return child;
}

ik_joint_t* ik_tree_init(glm::vec3 position)
{
	ik_joint_t* root = ik_joint_init();
	root->center = position;
	return root;
}

void ik_forward(ik_joint_t* joint)
{
	if(joint == nullptr)
	{ return; }

	for(ik_rod_t* rod : joint->children)
	{
		if(rod->child == nullptr)
		{ continue; }

		rod->child->center = joint->center + rod->axis * ROD_LENGTH;
		ik_forward(rod->child);
	}
}

void ik_backward(ik_joint_t* root, ik_rod_t* rod, ik_rod_t* effector, glm::vec3 target)
{
	if(root == nullptr || rod == nullptr)
	{ return; }

	glm::vec3 start = rod->parent->center;
	glm::vec3 end = effector->parent->center + effector->axis;

	glm::vec3 end_heading = glm::normalize(end - start);
	glm::vec3 target_heading = glm::normalize(target - start);

	glm::quat rotation = glm::rotation(end_heading, target_heading);
	rod->axis = rotation * rod->axis;
	rod->orientation = rotation * rod->orientation;

	ik_forward(root);
	ik_backward(root, rod->parent->parent, effector, target);
}

void ik_gather_leaves(ik_joint_t* root, std::vector<ik_rod_t*>& leaves)
{
	if(root == nullptr)
	{ return; }

	for(ik_rod_t* rod : root->children)
	{
		if(rod->child == nullptr)
		{ leaves.push_back(rod); }
		else
		{ ik_gather_leaves(rod->child, leaves); }
	}
}

void ik_mesh_spawn(scene_t& scene, ik_joint_t* joint)
{
	if(joint == nullptr)
	{ return; }

	transform_t transform = transform_init(joint->center);
	int idx = add_entity
	(
		scene, transform, collider_init(),
		renderer_init(scene.mesh_bank["joint"], scene.shader_bank["mesh"], scene.texture_bank["cogs"])
	);
	joint->entity_idx = idx;

	for(ik_rod_t* rod : joint->children)
	{
		transform = transform_init(joint->center);
		idx = add_entity
		(
			scene, transform, collider_init(),
			renderer_init(scene.mesh_bank[rod->child == nullptr ? "head" : "neck"], scene.shader_bank["mesh"], scene.texture_bank["cogs"])
		);
		rod->entity_idx = idx;
		ik_mesh_spawn(scene, rod->child);
	}
}

void ik_mesh_pose(scene_t& scene, ik_joint_t* joint)
{
	if(joint == nullptr)
	{ return; }

	transform_t* joint_transform = scene.transforms+joint->entity_idx;
	joint_transform->position = joint->center;

	for(ik_rod_t* rod : joint->children)
	{
		transform_t* rod_transform = scene.transforms+rod->entity_idx;
		rod_transform->orientation = rod->orientation;
		rod_transform->position = joint->center + rod->axis * ROD_LENGTH * 0.5f;
		ik_mesh_pose(scene, rod->child);
	}
}

void ik_tree_dispose(ik_joint_t* joint)
{
	if(joint == nullptr)
	{ return; }

	for(ik_rod_t* rod : joint->children)
	{
		ik_tree_dispose(rod->child);
		free(rod);
	}

	free(joint);
}
