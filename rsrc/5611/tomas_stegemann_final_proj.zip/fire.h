#pragma once

#include <stdlib.h>
#include <stdio.h>
#include "render.h"

#define FIRE_GRID_SIZE 35

/*void updateFireTexture();
renderer_t createFireModel(shader_t& shader);
void initFire();
void cleanFire();
void setFireValue(int x, int y, int z, float val);
void setFireVelocity(int x, int y, int z, float valX, float valY, float valZ);
void setOxygen(int x, int y, int z, float val);
float getOxygenValue(int x, int y, int z);
float getFireValue(int x, int y, int z);
float getFireVelX(int x, int y, int z);
float getFireVelY(int x, int y, int z);
void updateFire(float dt);*/

// #include "fire.h"
#include <vector>

float *fluidVelX, *oldFluidVelX, *fluidVelY, *oldFluidVelY, *fluidVelZ, *oldFluidVelZ;
float *heatGrid, *heatGridOld, *oxyGrid, *oxyGridOld;
float *diverge, *p;

texture_t fireTexture;
unsigned int textureData[FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE*3 * 4];

unsigned int createColor(float val) {
	float red, green, blue, alpha;
	val = fmax(0,val);
	if (val<1) {
		red = val/3;
		green = val/3;
		blue = val/3;
		alpha = fmax(0,(val/20) - 0.05);
	} else if (val<2) {
		val--;
		red = 2*val/3 + 1./3;
		green = 1./3 - val/3;
		blue = 1./3 - val/3;
		alpha = 0.05f;
	} else {
		val-=2;
		red = 1;
		green = fmin(1,val);
		blue = fmin(1,val/3);
		alpha = 0.05f;
	}

	int ret = (int) (alpha*255);
	ret = ret << 8;
	ret |= (int) (blue*255);
	ret = ret << 8;
	ret |= (int) (green*255);
	ret = ret << 8;
	ret |= (int) (red*255);

	return ret;
}

void updateFireTexture() {
	for (int k = 0; k < FIRE_GRID_SIZE; k++) {		//Level of propagation
		for (int j = 0; j < FIRE_GRID_SIZE; j++) {
			for (int i = 0; i < FIRE_GRID_SIZE; i++) {
				//x direction
				float val = heatGrid[i + j*FIRE_GRID_SIZE + k*FIRE_GRID_SIZE*FIRE_GRID_SIZE];
				textureData[0*FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE + j*FIRE_GRID_SIZE*FIRE_GRID_SIZE + i + k*FIRE_GRID_SIZE]
							= createColor(heatGrid[k + j*FIRE_GRID_SIZE + i*FIRE_GRID_SIZE*FIRE_GRID_SIZE]);
				//y direction
				textureData[1*FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE + j*FIRE_GRID_SIZE*FIRE_GRID_SIZE + i + k*FIRE_GRID_SIZE]
							= createColor(heatGrid[i + k*FIRE_GRID_SIZE + j*FIRE_GRID_SIZE*FIRE_GRID_SIZE]);
				//z direction
				textureData[2*FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE + j*FIRE_GRID_SIZE*FIRE_GRID_SIZE + i + k*FIRE_GRID_SIZE]
							= createColor(heatGrid[i + j*FIRE_GRID_SIZE + k*FIRE_GRID_SIZE*FIRE_GRID_SIZE]);
			}
		}
	}

	glBindTexture(GL_TEXTURE_2D, fireTexture.tex_id);
	glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, fireTexture.width, fireTexture.height, GL_RGBA, GL_UNSIGNED_BYTE, textureData);
	glGenerateMipmap(GL_TEXTURE_2D);
}

renderer_t createFireModel(shader_t& shader) {
	//Each quad is grid*grid, then there are grid of them for each dimension (and 4 bytes per pixel)
	for (int k = 0; k < FIRE_GRID_SIZE; k++) {		//Level of propagation
		for (int j = 0; j < FIRE_GRID_SIZE; j++) {
			for (int i = 0; i < FIRE_GRID_SIZE; i++) {
				//x direction
				float val = heatGrid[i + j*FIRE_GRID_SIZE + k*FIRE_GRID_SIZE*FIRE_GRID_SIZE];
				textureData[0*FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE + j*FIRE_GRID_SIZE*FIRE_GRID_SIZE + i + k*FIRE_GRID_SIZE]
							= createColor(heatGrid[i + j*FIRE_GRID_SIZE + k*FIRE_GRID_SIZE*FIRE_GRID_SIZE]);
				//y direction
				textureData[1*FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE + j*FIRE_GRID_SIZE*FIRE_GRID_SIZE + i + k*FIRE_GRID_SIZE]
							= createColor(heatGrid[i + k*FIRE_GRID_SIZE + j*FIRE_GRID_SIZE*FIRE_GRID_SIZE]);
				//z direction
				textureData[2*FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE + j*FIRE_GRID_SIZE*FIRE_GRID_SIZE + i + k*FIRE_GRID_SIZE]
							= createColor(heatGrid[k + i*FIRE_GRID_SIZE + j*FIRE_GRID_SIZE*FIRE_GRID_SIZE]);
			}
		}
	}

	//grid quads, in each 3 dimensions, with 4 points each quad, and each point having 8 values
	//First 3 floats are x,y,z next 3 are normals, next 2 are u,v
	GLfloat vertices[FIRE_GRID_SIZE*3*4*8];
	//2 triangles per quad, grid quads in every 3 dimensions
//	GLint indices[FIRE_GRID_SIZE*3*2*3];
	//2 triangles per face, 2 faces per quad, grid quads in every 3 dimensions
	GLint indices[FIRE_GRID_SIZE*3*2*2*3];

	memset(vertices,0,sizeof(GLfloat) * FIRE_GRID_SIZE * 3 * 4 * 8);
	memset(indices,0,sizeof(GLint) * FIRE_GRID_SIZE * 3 * 2 * 2 * 3);

	//Grid texture areas:
	//Row 1 is X propagating
	//Row 2 is Y propagating
	//Row 3 is Z propagating

	for (int i = 0; i < FIRE_GRID_SIZE; i++) {
		for (int x = 0; x < 2; x++) {
			for (int y = 0; y < 2; y++) {
				//X propagating
				vertices[(i*96) + 0 + x*16 + y*8] = (i+0.5f)/FIRE_GRID_SIZE;
				vertices[(i*96) + 1 + x*16 + y*8] = x;
				vertices[(i*96) + 2 + x*16 + y*8] = y;
				vertices[(i*96) + 3 + x*16 + y*8] = (i+x + (x?-1.f:1.f)/FIRE_GRID_SIZE)/(1.f*FIRE_GRID_SIZE);
				vertices[(i*96) + 4 + x*16 + y*8] = (y + (y?-1.f:1.f)/FIRE_GRID_SIZE)/3.f;
				vertices[(i*96) + 5 + x*16 + y*8] = 0;
				vertices[(i*96) + 6 + x*16 + y*8] = 1;
				vertices[(i*96) + 7 + x*16 + y*8] = 0;

				//Y propagating
				vertices[(i*96) + 32 + x*16 + y*8] = x;
				vertices[(i*96) + 33 + x*16 + y*8] = (i+0.5f)/FIRE_GRID_SIZE;
				vertices[(i*96) + 34 + x*16 + y*8] = y;
				vertices[(i*96) + 35 + x*16 + y*8] = (i+x + (x?-1.f:1.f)/FIRE_GRID_SIZE)/(1.f*FIRE_GRID_SIZE);
				vertices[(i*96) + 36 + x*16 + y*8] = (2+y + (y?-1.f:1.f)/FIRE_GRID_SIZE)/3.f;
				vertices[(i*96) + 37 + x*16 + y*8] = 0;
				vertices[(i*96) + 38 + x*16 + y*8] = 1;
				vertices[(i*96) + 39 + x*16 + y*8] = 0;

				//Z propagating
				vertices[(i*96) + 64 + x*16 + y*8] = x;
				vertices[(i*96) + 65 + x*16 + y*8] = y;
				vertices[(i*96) + 66 + x*16 + y*8] = (i+0.5f)/FIRE_GRID_SIZE;
				vertices[(i*96) + 67 + x*16 + y*8] = (i+x + (x?-1.f:1.f)/FIRE_GRID_SIZE)/(1.f*FIRE_GRID_SIZE);
				vertices[(i*96) + 68 + x*16 + y*8] = (1+y + (y?-1.f:1.f)/FIRE_GRID_SIZE)/3.f;
				vertices[(i*96) + 69 + x*16 + y*8] = 0;
				vertices[(i*96) + 70 + x*16 + y*8] = 1;
				vertices[(i*96) + 71 + x*16 + y*8] = 0;
			}
		}
	}

	for (int i = 0; i < FIRE_GRID_SIZE; i++) {
		indices[36*i + 0] = 12*i + 0 + 0 + 0;
		indices[36*i + 1] = 12*i + 0 + 2 + 1;
		indices[36*i + 2] = 12*i + 0 + 0 + 1;

		indices[36*i + 3] = 12*i + 0 + 0 + 0;
		indices[36*i + 4] = 12*i + 0 + 2 + 0;
		indices[36*i + 5] = 12*i + 0 + 2 + 1;

		indices[36*i + 6] = 12*i + 0 + 0 + 0;
		indices[36*i + 7] = 12*i + 0 + 0 + 1;
		indices[36*i + 8] = 12*i + 0 + 2 + 1;

		indices[36*i + 9] = 12*i + 0 + 0 + 0;
		indices[36*i + 10] = 12*i + 0 + 2 + 1;
		indices[36*i + 11] = 12*i + 0 + 2 + 0;

		indices[36*i + 12] = 12*i + 4 + 0 + 0;
		indices[36*i + 13] = 12*i + 4 + 2 + 1;
		indices[36*i + 14] = 12*i + 4 + 0 + 1;

		indices[36*i + 15] = 12*i + 4 + 0 + 0;
		indices[36*i + 16] = 12*i + 4 + 2 + 0;
		indices[36*i + 17] = 12*i + 4 + 2 + 1;

		indices[36*i + 18] = 12*i + 4 + 0 + 0;
		indices[36*i + 19] = 12*i + 4 + 0 + 1;
		indices[36*i + 20] = 12*i + 4 + 2 + 1;

		indices[36*i + 21] = 12*i + 4 + 0 + 0;
		indices[36*i + 22] = 12*i + 4 + 2 + 1;
		indices[36*i + 23] = 12*i + 4 + 2 + 0;

		indices[36*i + 24] = 12*i + 8 + 0 + 0;
		indices[36*i + 25] = 12*i + 8 + 2 + 1;
		indices[36*i + 26] = 12*i + 8 + 0 + 1;

		indices[36*i + 27] = 12*i + 8 + 0 + 0;
		indices[36*i + 28] = 12*i + 8 + 2 + 0;
		indices[36*i + 29] = 12*i + 8 + 2 + 1;

		indices[36*i + 30] = 12*i + 8 + 0 + 0;
		indices[36*i + 31] = 12*i + 8 + 0 + 1;
		indices[36*i + 32] = 12*i + 8 + 2 + 1;

		indices[36*i + 33] = 12*i + 8 + 0 + 0;
		indices[36*i + 34] = 12*i + 8 + 2 + 1;
		indices[36*i + 35] = 12*i + 8 + 2 + 0;
	}

//	for (int i = 0; i < FIRE_GRID_SIZE; i++) {
//		indices[18*i + 0] = 12*i + 0 + 0 + 0;
//		indices[18*i + 1] = 12*i + 0 + 2 + 1;
//		indices[18*i + 2] = 12*i + 0 + 0 + 1;
//
//		indices[18*i + 3] = 12*i + 0 + 0 + 0;
//		indices[18*i + 4] = 12*i + 0 + 2 + 0;
//		indices[18*i + 5] = 12*i + 0 + 2 + 1;
//
//		indices[18*i + 6] = 12*i + 4 + 0 + 0;
//		indices[18*i + 7] = 12*i + 4 + 2 + 1;
//		indices[18*i + 8] = 12*i + 4 + 0 + 1;
//
//		indices[18*i + 9] = 12*i + 4 + 0 + 0;
//		indices[18*i + 10] = 12*i + 4 + 2 + 0;
//		indices[18*i + 11] = 12*i + 4 + 2 + 1;
//
//		indices[18*i + 12] = 12*i + 8 + 0 + 0;
//		indices[18*i + 13] = 12*i + 8 + 2 + 1;
//		indices[18*i + 14] = 12*i + 8 + 0 + 1;
//
//		indices[18*i + 15] = 12*i + 8 + 0 + 0;
//		indices[18*i + 16] = 12*i + 8 + 2 + 0;
//		indices[18*i + 17] = 12*i + 8 + 2 + 1;
//	}

	// Model *ret = loadModelRaw(NULL, vertices, indices, FIRE_GRID_SIZE * 3 * 4, FIRE_GRID_SIZE * 3 * 2 * 2);

	glGenTextures(1, &fireTexture.tex_id);
	glBindTexture(GL_TEXTURE_2D, fireTexture.tex_id);

	fireTexture.channels = 4;
	fireTexture.width = FIRE_GRID_SIZE*FIRE_GRID_SIZE;
	fireTexture.height = FIRE_GRID_SIZE*3;

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, fireTexture.width, fireTexture.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, textureData);
	glGenerateMipmap(GL_TEXTURE_2D);
	
	vertex_t* cast_vert_arr = (vertex_t*) vertices;
	std::vector<vertex_t> cast_vert_vec = std::vector<vertex_t>(cast_vert_arr, cast_vert_arr + FIRE_GRID_SIZE);
	mesh_t mesh = mesh_init(cast_vert_vec, GL_TRIANGLES);
	renderer_t renderer = renderer_init(mesh, shader, fireTexture);

	return renderer;
}

void initFire() {
	heatGrid = (float*) malloc(sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	heatGridOld = (float*) malloc(sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	oxyGrid = (float*) malloc(sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	oxyGridOld = (float*) malloc(sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	fluidVelX = (float*) malloc(sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	fluidVelY = (float*) malloc(sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	fluidVelZ = (float*) malloc(sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	oldFluidVelX = (float*) malloc(sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	oldFluidVelY = (float*) malloc(sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	oldFluidVelZ = (float*) malloc(sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	memset(heatGrid, 0, sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	memset(heatGridOld, 0, sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
//	for (int i = 0; i < FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE; i++) heatGrid[i] = 0.7;
	for (int i = 0; i < FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE; i++) oxyGrid[i] = 3;
	for (int i = 0; i < FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE; i++) oxyGridOld[i] = 3;
	memset(fluidVelX, 0, sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	memset(fluidVelY, 0, sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	memset(fluidVelZ, 0, sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	memset(oldFluidVelX, 0, sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	memset(oldFluidVelY, 0, sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	memset(oldFluidVelZ, 0, sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);

	diverge = (float*) malloc(sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	p = (float*) malloc(sizeof(float) * FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
}

void cleanFire() {
	free(heatGrid);
	free(heatGridOld);
	free(oxyGrid);
	free(oxyGridOld);
	free(fluidVelX);
	free(fluidVelY);
	free(oldFluidVelX);
	free(oldFluidVelY);

	free(diverge);
	free(p);
}

void setFireVelocity(int x, int y, int z, float valX, float valY, float valZ) {
	fluidVelX[x+y*FIRE_GRID_SIZE+z*FIRE_GRID_SIZE*FIRE_GRID_SIZE] = valX;
	oldFluidVelX[x+y*FIRE_GRID_SIZE+z*FIRE_GRID_SIZE*FIRE_GRID_SIZE] = valX;
	fluidVelY[x+y*FIRE_GRID_SIZE+z*FIRE_GRID_SIZE*FIRE_GRID_SIZE] = valY;
	oldFluidVelY[x+y*FIRE_GRID_SIZE+z*FIRE_GRID_SIZE*FIRE_GRID_SIZE] = valY;
	fluidVelZ[x+y*FIRE_GRID_SIZE+z*FIRE_GRID_SIZE*FIRE_GRID_SIZE] = valZ;
	oldFluidVelZ[x+y*FIRE_GRID_SIZE+z*FIRE_GRID_SIZE*FIRE_GRID_SIZE] = valZ;
}

void setFireValue(int x, int y, int z, float val) {
	heatGrid[x+y*FIRE_GRID_SIZE+z*FIRE_GRID_SIZE*FIRE_GRID_SIZE] = val;
	heatGridOld[x+y*FIRE_GRID_SIZE+z*FIRE_GRID_SIZE*FIRE_GRID_SIZE] = val;
}

void setOxygen(int x, int y, int z, float val) {
	oxyGrid[x+y*FIRE_GRID_SIZE+z*FIRE_GRID_SIZE*FIRE_GRID_SIZE] = val;
	oxyGridOld[x+y*FIRE_GRID_SIZE+z*FIRE_GRID_SIZE*FIRE_GRID_SIZE] = val;
}

float getOxygenValue(int x, int y, int z) {
	return oxyGrid[x+y*FIRE_GRID_SIZE+z*FIRE_GRID_SIZE*FIRE_GRID_SIZE];
}

float getFireValue(int x, int y, int z) {
	return heatGrid[x+y*FIRE_GRID_SIZE+z*FIRE_GRID_SIZE*FIRE_GRID_SIZE];
}

float getFireVelX(int x, int y, int z) {
	return fluidVelX[x+y*FIRE_GRID_SIZE+z*FIRE_GRID_SIZE*FIRE_GRID_SIZE];
}

float getFireVelY(int x, int y, int z) {
	return fluidVelY[x+y*FIRE_GRID_SIZE+z*FIRE_GRID_SIZE*FIRE_GRID_SIZE];
}

void setBounds(int type, float *array) {
	for (int j = 0; j < FIRE_GRID_SIZE; j++) {
		for (int i = 0; i < FIRE_GRID_SIZE; i++) {
			//Bottom plane
			array[i+FIRE_GRID_SIZE*j] = (type == 3 ? -1 : 1) * array[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE];
			//Top plane
			array[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1)] = (type == 3 ? -1 : 1) * array[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-2)];
			//Left plane
			array[i+FIRE_GRID_SIZE*FIRE_GRID_SIZE*j] = (type == 2 ? -1 : 1) * array[i+FIRE_GRID_SIZE*FIRE_GRID_SIZE*j + FIRE_GRID_SIZE];
			//Right plane
			array[i+FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1)+FIRE_GRID_SIZE*FIRE_GRID_SIZE*j] = (type == 2 ? -1 : 1) * array[i+FIRE_GRID_SIZE*FIRE_GRID_SIZE*j + FIRE_GRID_SIZE*(FIRE_GRID_SIZE-2)];
			//Back plane
			array[FIRE_GRID_SIZE-1 + FIRE_GRID_SIZE*i + FIRE_GRID_SIZE*FIRE_GRID_SIZE*j] = (type == 1 ? -1 : 1) * array[FIRE_GRID_SIZE-2 + FIRE_GRID_SIZE*i + FIRE_GRID_SIZE*FIRE_GRID_SIZE*j];
			//Front plane
			array[FIRE_GRID_SIZE*i + FIRE_GRID_SIZE*FIRE_GRID_SIZE*j] = (type == 1 ? -1 : 1) * array[1 + FIRE_GRID_SIZE*i + FIRE_GRID_SIZE*FIRE_GRID_SIZE*j];
		}
	}

	//Corners. This was annoying
	array[0] = (array[1] + array[FIRE_GRID_SIZE] + array[FIRE_GRID_SIZE*FIRE_GRID_SIZE])/3;
	array[FIRE_GRID_SIZE-1] = (array[FIRE_GRID_SIZE-2] + array[2*FIRE_GRID_SIZE-1] + array[FIRE_GRID_SIZE*FIRE_GRID_SIZE + FIRE_GRID_SIZE-1])/3;
	array[FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1)] = (array[FIRE_GRID_SIZE*(FIRE_GRID_SIZE-2)] + array[FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1)+1] + array[FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1) + FIRE_GRID_SIZE*FIRE_GRID_SIZE])/3;
	array[FIRE_GRID_SIZE*FIRE_GRID_SIZE-1] = (array[FIRE_GRID_SIZE*FIRE_GRID_SIZE-2] + array[FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1)-1] + array[2*FIRE_GRID_SIZE*FIRE_GRID_SIZE-1])/3;

	array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1)] = (array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-2)] + array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1) + 1] + array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1) + FIRE_GRID_SIZE])/3;
	array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1)+FIRE_GRID_SIZE-1] = (array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-2)+FIRE_GRID_SIZE-1] + array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1)+FIRE_GRID_SIZE-2] + array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1)+2*FIRE_GRID_SIZE-1])/3;
	array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1)+FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1)] = (array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-2)+FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1)] + array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1)+FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1)+1] + array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1)+FIRE_GRID_SIZE*(FIRE_GRID_SIZE-2)])/3;
	array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE-1] = (array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE-2] + array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1) + FIRE_GRID_SIZE*(FIRE_GRID_SIZE-1) - 1] + array[FIRE_GRID_SIZE*FIRE_GRID_SIZE*(FIRE_GRID_SIZE-2) - 1])/3;
}

void diffuse(float *x, float *xOld, float diffusion, float dt) {
	float a = dt*diffusion*FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE;
	for (int k = 0; k < FIRE_GRID_SIZE; k++) {
		for (int j = 0; j < FIRE_GRID_SIZE; j++) {
			for (int i = 0; i < FIRE_GRID_SIZE; i++) {
				x[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] = 0;
				if (i>0)	x[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] += x[i-1+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k];
				if (i<FIRE_GRID_SIZE-1)	x[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] += x[i+1+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k];
				if (j>0)	x[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] += x[i+FIRE_GRID_SIZE*(j-1)+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k];
				if (j<FIRE_GRID_SIZE-1)	x[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] += x[i+FIRE_GRID_SIZE*(j+1)+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k];
				if (k>0)	x[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] += x[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*(k-1)];
				if (k<FIRE_GRID_SIZE-1)	x[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] += x[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*(k+1)];

				x[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] *= a;
				x[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] += xOld[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k];
				x[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] /= 1.+6*a;
			}
		}
	}
}

void diffuseCount(float *x, float *xOld, float diffusion, float dt) {
	float a = dt*diffusion*FIRE_GRID_SIZE*FIRE_GRID_SIZE;
	for (int k = 0; k < 5; k++)
	for (int j = 0; j < FIRE_GRID_SIZE; j++) {
		for (int i = 0; i < FIRE_GRID_SIZE; i++) {
			x[i+FIRE_GRID_SIZE*j] = 0;
			int count = 0;
			if (i>0) {	x[i+FIRE_GRID_SIZE*j] += x[i-1+FIRE_GRID_SIZE*j]; count++; }
			if (i<FIRE_GRID_SIZE-1) {	x[i+FIRE_GRID_SIZE*j] += x[i+1+FIRE_GRID_SIZE*j]; count++; }
			if (j>0) {	x[i+FIRE_GRID_SIZE*j] += x[i+FIRE_GRID_SIZE*(j-1)]; count++; }
			if (j<FIRE_GRID_SIZE-1) {	x[i+FIRE_GRID_SIZE*j] += x[i+FIRE_GRID_SIZE*(j+1)]; count++; }

			x[i+FIRE_GRID_SIZE*j] *= a;
			x[i+FIRE_GRID_SIZE*j] += xOld[i+FIRE_GRID_SIZE*j];
			x[i+FIRE_GRID_SIZE*j] /= 1.+count*a;
		}
	}
}

void advect(float *d, float *dOld, float *velX, float *velY, float *velZ, float dt, float b) {
	float dt0 = dt*FIRE_GRID_SIZE*b;
	for (int k = 0; k < FIRE_GRID_SIZE; k++) {
		for (int j = 0; j < FIRE_GRID_SIZE; j++) {
			for (int i = 0; i < FIRE_GRID_SIZE; i++) {
				float x = i - dt0*velX[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k], y = j - dt0*velY[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k], z = k - dt0*velZ[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k];
				x = x < 0.5 ? 0.5 : x > FIRE_GRID_SIZE - 1.5 ? FIRE_GRID_SIZE - 1.5 : x;
				y = y < 0.5 ? 0.5 : y > FIRE_GRID_SIZE - 1.5 ? FIRE_GRID_SIZE - 1.5 : y;
				z = z < 0.5 ? 0.5 : z > FIRE_GRID_SIZE - 1.5 ? FIRE_GRID_SIZE - 1.5 : z;
				int i0 = (int) x, j0 = (int) y, k0 = (int) z, i1 = i0 + 1, j1 = j0 + 1, k1 = k0 + 1;
				float s1 = x-i0, s0 = 1-s1, t1 = y-j0, t0 = 1-t1, u1 = z-k0, u0 = 1-u1;
				d[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] =
						u0*(
							s0*(t0*dOld[i0+FIRE_GRID_SIZE*j0+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k0]+t1*dOld[i0+FIRE_GRID_SIZE*j1+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k0])
						  + s1*(t0*dOld[i1+FIRE_GRID_SIZE*j0+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k0]+t1*dOld[i1+FIRE_GRID_SIZE*j1+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k0])
						)
						+ u1*(
							s0*(t0*dOld[i0+FIRE_GRID_SIZE*j0+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k1]+t1*dOld[i0+FIRE_GRID_SIZE*j1+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k1])
						  + s1*(t0*dOld[i1+FIRE_GRID_SIZE*j0+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k1]+t1*dOld[i1+FIRE_GRID_SIZE*j1+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k1])
						);
			}
		}
	}
}

//To update to 3D
void project(float *velX, float *velY, float *velZ, float hn) {
	memset(p,0,sizeof(float)*FIRE_GRID_SIZE*FIRE_GRID_SIZE*FIRE_GRID_SIZE);
	for (int k = 1; k < FIRE_GRID_SIZE-1; k++) {
		for (int j = 1; j < FIRE_GRID_SIZE-1; j++) {
			for (int i = 1; i < FIRE_GRID_SIZE-1; i++) {
				diverge[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] = -(1./3)*hn*(velX[i+1+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k]-velX[i-1+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k]+velY[i+FIRE_GRID_SIZE*(j+1)+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k]-velY[i+FIRE_GRID_SIZE*(j-1)+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k]+velZ[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*(k+1)]-velZ[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*(k-1)]);
			}
		}
	}

	setBounds(0, diverge); setBounds(0, p);

	for (int k = 1; k < FIRE_GRID_SIZE-1; k++) {
		for (int j = 1; j < FIRE_GRID_SIZE-1; j++) {
			for (int i = 1; i < FIRE_GRID_SIZE-1; i++) {
				p[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] = (diverge[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] +
						p[i-1+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] + p[i+1+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] +
						p[i+FIRE_GRID_SIZE*(j-1)+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] + p[i+FIRE_GRID_SIZE*(j+1)+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] +
						p[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*(k-1)] + p[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*(k+1)])/6;
			}
		}
	}

	setBounds(0,p);

	for (int k = 1; k < FIRE_GRID_SIZE-1; k++) {
		for (int j = 1; j < FIRE_GRID_SIZE-1; j++) {
			for (int i = 1; i < FIRE_GRID_SIZE-1; i++) {
				velX[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] -= (1./3)*(p[i+1+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k]-p[i-1+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k])/hn;
				velY[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] -= (1./3)*(p[i+FIRE_GRID_SIZE*(j+1)+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k]-p[i+FIRE_GRID_SIZE*(j-1)+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k])/hn;
				velZ[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] -= (1./3)*(p[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*(k+1)]-p[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*(k-1)])/hn;
			}
		}
	}

	setBounds(1,velX); setBounds(2,velY); setBounds(3,velZ);
}

void stepGrid(float *x, float *xOld, float dt, float diffusion, float advection) {
	float *ptr;
	ptr = xOld; xOld = x; x = ptr;
	diffuse(x, xOld, diffusion, dt);
	ptr = xOld; xOld = x; x = ptr;
	advect(x, xOld, fluidVelX, fluidVelY, fluidVelZ, dt, advection);
}

void stepGridCount(float *x, float *xOld, float dt, float diffusion, float advection) {
	float *ptr;
	ptr = xOld; xOld = x; x = ptr;
	diffuseCount(x, xOld, diffusion, dt);
	ptr = xOld; xOld = x; x = ptr;
	advect(x, xOld, fluidVelX, fluidVelY, fluidVelZ, dt, advection);
}

void updateFire(float dt) {
	for (int k = 0; k < FIRE_GRID_SIZE; k++) {
		for (int j = 0; j < FIRE_GRID_SIZE; j++) {
			for (int i = 0; i < FIRE_GRID_SIZE; i++) {
				int index = i + FIRE_GRID_SIZE*j + FIRE_GRID_SIZE*FIRE_GRID_SIZE*k;
				float oxy = oxyGrid[index];
	//			oxyGrid[index]+=dt;
				float heat = heatGrid[index];

				int perform = 0;

				if (k==4) {
					float dist = (i-15)*(i-15)+(j-15)*(j-15);
					if (dist<25) {
						perform = 1;
					}
//				} else if (k==4) {
//					if (j>FIRE_GRID_SIZE/2 && j < FIRE_GRID_SIZE/2+10)
//					if (i>FIRE_GRID_SIZE/2 - 10 && i < FIRE_GRID_SIZE/2 - 3) {
//						perform = 1;
//					}
				}

				if (perform) {
					float rate = (oxy*heat - 0.4f) * 80;
					if (rate<0) rate = 0;
					if (rate>500) rate = 500;
	//				oxyGrid[index] -= rate*dt;
					heatGrid[index] += rate*dt;
				}
			}
		}
	}

	for (int k = 1; k < FIRE_GRID_SIZE-1; k++) {
		for (int j = 1; j < FIRE_GRID_SIZE-1; j++) {
			for (int i = 1; i < FIRE_GRID_SIZE-1; i++) {
				fluidVelZ[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] += heatGrid[i+FIRE_GRID_SIZE*j+FIRE_GRID_SIZE*FIRE_GRID_SIZE*k] * 1.75 * dt;
			}
		}
	}

	//Step velocity vectors
	float *ptr;

//	setBounds(0, heatGrid);
//	return;

	//Diffusion
	ptr = oldFluidVelX; oldFluidVelX = fluidVelX; fluidVelX = ptr;
	diffuse(fluidVelX, oldFluidVelX, 0.001, dt);
	ptr = oldFluidVelY; oldFluidVelY = fluidVelY; fluidVelY = ptr;
	diffuse(fluidVelY, oldFluidVelY, 0.001, dt);
	ptr = oldFluidVelZ; oldFluidVelZ = fluidVelZ; fluidVelZ = ptr;
	diffuse(fluidVelZ, oldFluidVelZ, 0.001, dt);

	//Advection
	ptr = oldFluidVelX; oldFluidVelX = fluidVelX; fluidVelX = ptr;
	advect(fluidVelX, oldFluidVelX, fluidVelX, fluidVelY, fluidVelZ, dt, 1.25);

	ptr = oldFluidVelY; oldFluidVelY = fluidVelY; fluidVelY = ptr;
	advect(fluidVelY, oldFluidVelY, fluidVelX, fluidVelY, fluidVelZ, dt, 1.25);

	ptr = oldFluidVelZ; oldFluidVelZ = fluidVelZ; fluidVelZ = ptr;
	advect(fluidVelZ, oldFluidVelZ, fluidVelX, fluidVelY, fluidVelZ, dt, 1.25);

	project(fluidVelX, fluidVelY, fluidVelZ, 0.01);

	stepGrid(heatGrid, heatGridOld, dt, 0.001, 4);
//	stepGridCount(oxyGrid, oxyGridOld, dt, 0.025, 1);
}
