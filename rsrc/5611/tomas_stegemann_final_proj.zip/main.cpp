#include <iostream>
#include <cstdlib>
#include <math.h>
#include <vector>
#include <float.h>
#include <chrono>
#include <time.h>
#include <map>
#include <list>

#include <GL/glew.h> 
#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>

#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/string_cast.hpp>

#include "mesh.h"
#include "shader.h"
#include "scene.h"
#include "window.h"
#include "cowtools.h"
#include "camera.h"
#include "assets.h"
#include "ik_tree.h"
#include "hydra.h"

void render_scene(scene_t& scene, window_t& window, camera_t& camera)
{
	for(int i = 0; i < scene.n_entities; i++)
	{
		if(scene.renderers[i].enabled)
		{ render(scene.renderers[i], scene.transforms[i], camera); }
		if(scene.gizmos[i].enabled)
		{ render(scene.gizmos[i], scene.transforms[i], camera); }
	}
}

int main(int argc, char** argv) 
{
	srand(time(NULL));

	// INIT WINDOW
	window_t window = window_init("Engine", glm::ivec2(1280, 720));
	std::cerr << "initialized window" << std::endl;

	// INIT SCENE
	scene_t scene = scene_init(10000);

	int sky =
	add_entity
	(
		scene, transform_init(glm::vec3(0)), collider_init(),
		renderer_init(scene.mesh_bank["sky"], scene.shader_bank["sky"], scene.texture_bank["none"])
	);
	scene.renderers[sky].enabled = false; // sky is rendered separately

	mesh_t grid_mesh = mesh_plane_init(glm::vec3(0,0,1));
	int grid =
	add_entity
	(
		scene, transform_init(glm::vec3(0)), collider_init(),
		renderer_init(grid_mesh, scene.shader_bank["grid"], scene.texture_bank["none"])
	);
	scene.renderers[grid].enabled = false; // grid is rendered separately
	
	int building = add_entity
	(
		scene, transform_init(glm::vec3(0)), collider_init(),
		renderer_init(scene.mesh_bank["sponza"], scene.shader_bank["mesh"], scene.texture_bank["grid"])
	);
	scene.transforms[building].scale = glm::vec3(0.025f);

	camera_t camera = camera_init
	(
		transform_init(glm::vec3(15,2,0)), // pos
		M_PI/2, // fov
		window.dimensions.x / (float) window.dimensions.y, // aspect
		0.1f, 10000.0f // near and far
	);
	
	ik_joint_t* ik_root = spawn_hydra(scene, 3, 3, 5);

	std::cerr << "initialized scene" << std::endl;
	
	// CONFIGURE RENDERER
	glEnable(GL_DEPTH_TEST);
	//glEnable(GL_CULL_FACE);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	// CONFIGURE ENGINE STATE
	std::chrono::time_point<std::chrono::system_clock> ft_last = std::chrono::system_clock::now();
	std::chrono::time_point<std::chrono::system_clock> ft = std::chrono::system_clock::now();
	std::chrono::duration<float> dft;
	glm::vec2 fm_last = get_mouse_pos(window);
	glm::vec2 fm = get_mouse_pos(window);
	glm::vec2 dm;

	// ENGINE GO!
	while(!glfwWindowShouldClose(window.handle))
	{
		// TIMING
		ft = std::chrono::system_clock::now();
		dft = ft - ft_last;
		ft_last = ft;
		float dt = dft.count();
		
		// INPUT
		glfwPollEvents();
		fm = get_mouse_pos(window);
		dm = fm - fm_last;
		fm_last = fm;
		glfwSetInputMode(window.handle, GLFW_CURSOR, window.paused ? GLFW_CURSOR_NORMAL : GLFW_CURSOR_DISABLED); 
		camera.transform.orientation = glm::quat(glm::vec3(-fm.y, -fm.x, 0));
		
		glm::vec3 forward = make_forward(camera.transform);
		glm::vec3 right = make_right(camera.transform);
		glm::vec3 wasd = glm::vec3(0,0,0);
		if(glfwGetKey(window.handle, GLFW_KEY_W) == GLFW_PRESS)
		{ wasd += forward; }
		if(glfwGetKey(window.handle, GLFW_KEY_A) == GLFW_PRESS)
		{ wasd += right; }
		if(glfwGetKey(window.handle, GLFW_KEY_S) == GLFW_PRESS)
		{ wasd -= forward; }
		if(glfwGetKey(window.handle, GLFW_KEY_D) == GLFW_PRESS)
		{ wasd -= right; }
		wasd.y = 0;
		wasd = glm::length(wasd) > 0.0f ? glm::normalize(wasd) : wasd;
		camera.transform.velocity = wasd * (glfwGetKey(window.handle, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS ? 15.0f : 10.0f);
			
		// PHYSICS
		euler_integrate(camera.transform, dt);
		if(camera.transform.position.y < 2)
		{ camera.transform.position.y = 2; }
		
		glm::vec3 ik_target = camera.transform.position + make_forward(camera.transform);
		target_hydra(ik_root, ik_target, 16);
		ik_mesh_pose(scene, ik_root);

		// DRAWING
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Draw background cube
		glDepthMask(GL_FALSE);
		render(scene.renderers[sky], scene.transforms[sky], camera);
		glDepthMask(GL_TRUE);

		// Draw opaque objects
		render_scene(scene, window, camera);

		// Draw transparent grid
		render(scene.renderers[grid], scene.transforms[grid], camera);

		glfwSwapBuffers(window.handle);
	}

	// SCENE CLEANUP
	scene_erase(scene);
	scene_dispose(scene);
	std::cerr << "disposed of scene" << std::endl;

	// CONTEXT CLEANUP
	window_dispose(window);
	std::cerr << "disposed of window" << std::endl;

  	return 0;
}
