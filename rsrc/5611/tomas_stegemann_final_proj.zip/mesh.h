#pragma once

#include <stdlib.h>
#include <math.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <filesystem>
#include <string_view>
#include <sstream>

#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>
#include <GL/glew.h> 

#include <glm/glm.hpp>
#include <glm/gtc/matrix_access.hpp>
#include <glm/gtx/string_cast.hpp>

#include "shape.h"
#include "obj.h"

struct vertex_t
{
	glm::vec3 pos;
	glm::vec2 uv;
	glm::vec3 norm;
};

vertex_t vertex_init(glm::vec3 pos, glm::vec2 uv, glm::vec3 norm)
{
	vertex_t v;
	v.pos = pos;
	v.uv = uv;
	v.norm = norm;
	return v;
}

struct mesh_t
{
	GLuint vao_id;
	GLuint vbo_id;
	std::vector<vertex_t> verts;
	GLenum mode;
};

mesh_t mesh_init(std::vector<vertex_t> verts, GLenum mode)
{
	GLuint vao_id;
	glGenVertexArrays(1, &vao_id);
	glBindVertexArray(vao_id);

	GLuint vbo_id;
	glGenBuffers(1, &vbo_id);
	glBindBuffer(GL_ARRAY_BUFFER, vbo_id);
	glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(vertex_t), verts.data(), GL_STATIC_DRAW);
	
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(vertex_t), (void*) offsetof(vertex_t, pos));
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(vertex_t), (void*) offsetof(vertex_t, uv));
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(vertex_t), (void*) offsetof(vertex_t, norm));
	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
	glEnableVertexAttribArray(2);
	
	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	mesh_t mesh;
	mesh.vao_id = vao_id;
	mesh.vbo_id = vbo_id;
	mesh.verts = verts;
	mesh.mode = mode;

	return mesh;
}

void mesh_dispose(const mesh_t& mesh)
{
	if(mesh.verts.empty())
	{ return; }

	glDeleteVertexArrays(1, &mesh.vao_id);
	glDeleteBuffers(1, &mesh.vbo_id);
}

mesh_t mesh_OBJ_init(OBJ_t& obj)
{
	std::vector<vertex_t> verts = std::vector<vertex_t>();

	for(glm::mat3 f : obj.fs)
	{
		for(int i = 0; i < 3; i++)
		{
			glm::vec3 p = glm::column(f, i);

			glm::vec3 v = obj.vs[p[0]-1];
			glm::vec2 vt = obj.vts[p[1]-1];
			glm::vec3 vn = obj.vns[p[2]-1];

			verts.push_back(vertex_init(v, vt, vn));
		}
	}

	return mesh_init(verts, GL_TRIANGLES);
}

mesh_t mesh_sphere_init(sphere_t sphere)
{
	std::vector<vertex_t> verts = std::vector<vertex_t>();
	for(int i = 0; i < 3; i++)
	{
		glm::vec3 axis = glm::vec3(); axis[i] = 1;
		std::vector<glm::vec3> ring = make_ring(axis, sphere.r, 16);
		for(int i = 0; i < ring.size()-1; i++)
		{
			verts.push_back(vertex_init(ring[i]+sphere.c, glm::vec2(), glm::vec3()));
			verts.push_back(vertex_init(ring[i+1]+sphere.c, glm::vec2(), glm::vec3()));
		}
		verts.push_back(vertex_init(ring.back(), glm::vec2(), glm::vec3()));
		verts.push_back(vertex_init(ring[0], glm::vec2(), glm::vec3()));
	}
	return mesh_init(verts, GL_LINES);
}

mesh_t mesh_box_init(box_t box)
{
	std::vector<vertex_t> verts = std::vector<vertex_t>();
	glm::vec3 min_x = glm::vec3(box.min.x,0,0);
	glm::vec3 min_y = glm::vec3(0,box.min.y,0);
	glm::vec3 min_z = glm::vec3(0,0,box.min.z);
	glm::vec3 max_x = glm::vec3(box.max.x,0,0);
	glm::vec3 max_y = glm::vec3(0,box.max.y,0);
	glm::vec3 max_z = glm::vec3(0,0,box.max.z);
	verts.push_back(vertex_init(min_x, glm::vec2(), glm::vec3()));
	verts.push_back(vertex_init(max_x, glm::vec2(), glm::vec3()));
	verts.push_back(vertex_init(min_y, glm::vec2(), glm::vec3()));
	verts.push_back(vertex_init(max_y, glm::vec2(), glm::vec3()));
	verts.push_back(vertex_init(min_y, glm::vec2(), glm::vec3()));
	verts.push_back(vertex_init(max_y, glm::vec2(), glm::vec3()));
	return mesh_init(verts, GL_LINES);
}

mesh_t mesh_line_init(line_t line)
{
	std::vector<vertex_t> verts = std::vector<vertex_t>();
	verts.push_back(vertex_init(line.a, glm::vec2(), glm::vec3()));
	verts.push_back(vertex_init(line.b, glm::vec2(), glm::vec3()));
	return mesh_init(verts, GL_LINES);
}

mesh_t mesh_plane_init(glm::vec3 normal)
{
	glm::mat3 basis = normal_basis(normal);
	glm::vec3 o = glm::vec3(0);
	glm::vec3 u = glm::normalize(glm::column(basis, 0));
	glm::vec3 v = glm::normalize(glm::column(basis, 1));
	glm::vec3 w = glm::normalize(glm::column(basis, 2));

	glm::vec3 bl = o - u - v;
	glm::vec3 tl = o - u + v;
	glm::vec3 tr = o + u + v;
	glm::vec3 br = o + u - v;
	
	std::vector<vertex_t> verts = std::vector<vertex_t>();
	verts.push_back(vertex_init(bl, glm::vec2(0,0), w));
	verts.push_back(vertex_init(tr, glm::vec2(1,1), w));
	verts.push_back(vertex_init(tl, glm::vec2(0,1), w));
	verts.push_back(vertex_init(tr, glm::vec2(1,1), w));
	verts.push_back(vertex_init(bl, glm::vec2(0,0), w));
	verts.push_back(vertex_init(br, glm::vec2(1,0), w));
	return mesh_init(verts, GL_TRIANGLES);
}

