#pragma once

#include <glm/glm.hpp>
#include <glm/gtx/norm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtx/string_cast.hpp>

enum shape_type_t
{
	SPHERE,
	BOX,
	LINE,

};

struct sphere_t
{
	glm::vec3 c;
	float r;
};

sphere_t sphere_init(glm::vec3 c, float r)
{
	sphere_t s;
	s.c = c;
	s.r = r;
	return s;
}

glm::mat4 sphere_model(sphere_t s)
{
	return glm::scale(glm::vec3(s.r));
}

struct box_t
{
	glm::vec3 min;
	glm::vec3 max;
};

box_t box_init(glm::vec3 min, glm::vec3 max)
{
	box_t b;
	b.min = min;
	b.max = max;
	return b;
}

glm::mat4 box_model(box_t b)
{
	return glm::scale(b.max - b.min);
}

struct line_t
{
	glm::vec3 a;
	glm::vec3 b;
};

line_t line_init(glm::vec3 a, glm::vec3 b)
{
	line_t l;
	l.a = a;
	l.b = b;
	return l;
}

glm::mat4 line_model(line_t l)
{
	glm::vec3 ref = glm::vec3(1, 0, 0);
	glm::vec3 skew = l.b - l.a;
	float scale = glm::length(skew);
	glm::mat4 scaling = glm::scale(glm::vec3(scale));
	float align = glm::dot(ref, skew);
	if(fabs(align) == 1)
	{ return scaling; }
	float angle = glm::acos(align);
	glm::vec3 axis = glm::normalize(glm::cross(ref, skew));
	glm::mat4 rotating = glm::rotate(angle, axis);
	return rotating * scaling;
}

