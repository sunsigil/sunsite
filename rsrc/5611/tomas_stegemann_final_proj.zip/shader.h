#pragma once

#include <iostream>
#include <fstream>
#include <sstream>

#include <GL/glew.h> 
#include <GLFW/glfw3.h>

struct shader_t
{
	std::string name;

	std::string vert_src;
	std::string frag_src;

	GLuint vert_id;
	GLuint frag_id;
	GLuint prog_id;
};

shader_t load_shader(std::string vert_path, std::string frag_path)
{
	int shader_status;
	char shader_log[512];

	std::ifstream vert_file = std::ifstream(vert_path);
	std::stringstream vert_stream;
	vert_stream << vert_file.rdbuf();
	std::string vert_src = vert_stream.str();
	vert_file.close();
	
	unsigned int vert_id = glCreateShader(GL_VERTEX_SHADER);
	char* vert_src_cstr = new char[vert_src.size()+1];
	memcpy(vert_src_cstr, vert_src.c_str(), vert_src.size()+1);
	glShaderSource(vert_id, 1, &vert_src_cstr, NULL);
	glCompileShader(vert_id);
	delete[] vert_src_cstr;
	
	std::cerr << "compiling vertex program " << vert_path << std::endl;
	glGetShaderiv(vert_id, GL_COMPILE_STATUS, &shader_status);
	if(!shader_status)
	{
		glGetShaderInfoLog(vert_id, 512, NULL, shader_log);
		std::cerr << "Failed to compile vertex shader: " << vert_path << std::endl;
		std::cerr << shader_log << std::endl;
	}

	std::ifstream frag_file = std::ifstream(frag_path);
	std::stringstream frag_stream;
	frag_stream << frag_file.rdbuf();
	std::string frag_src = frag_stream.str();
	frag_file.close();
	
	unsigned int frag_id = glCreateShader(GL_FRAGMENT_SHADER);
	char* frag_src_cstr = new char[frag_src.size()+1];
	memcpy(frag_src_cstr, frag_src.c_str(), frag_src.size()+1);
	glShaderSource(frag_id, 1, &frag_src_cstr, NULL);
	glCompileShader(frag_id);
	delete[] frag_src_cstr;

	std::cerr << "compiling fragment program " << frag_path << std::endl;
	glGetShaderiv(frag_id, GL_COMPILE_STATUS, &shader_status);
	if(!shader_status)
	{
		glGetShaderInfoLog(frag_id, 512, NULL, shader_log);
		std::cerr << "Failed to compile fragment shader: " << frag_path << std::endl;
		std::cerr << shader_log << std::endl;
	}

	unsigned int prog_id = glCreateProgram();
	glAttachShader(prog_id, vert_id);
	glAttachShader(prog_id, frag_id);
	glLinkProgram(prog_id);
	
	glGetShaderiv(prog_id, GL_LINK_STATUS, &shader_status);
	if(!shader_status)
	{
		glGetShaderInfoLog(prog_id, 512, NULL, shader_log);
		std::cerr << shader_log << std::endl;
	}

	shader_t shader;
	shader.name = vert_path;
	shader.vert_src = vert_src;
	shader.frag_src = frag_src;
	shader.vert_id = vert_id;
	shader.frag_id = frag_id;
	shader.prog_id = prog_id;
	return shader;
}

void shader_dispose(const shader_t& shader)
{
	glDeleteShader(shader.frag_id);
	glDeleteShader(shader.vert_id);
}


