struct line_t
{
	vec2_t p0;
	vec2_t p1;	
	colour_t c;
};

line_t line_init(vec2_t p0, vec2_t p1, colour_t c)
{ return (line_t) {p0, p1, c}; }

std::vector<line_t> line_trace(shape_t L1, colour_t c)
{
	std::vector<line_t> lines = std::vector<line_t>();
	lines.push_back(line_init(L1.a, vec2_add(L1.a, L1.b), c));
	return lines;
}

std::vector<line_t> circle_trace(shape_t C1, colour_t c)
{
	std::vector<line_t> lines = std::vector<line_t>();
	float arc = 2.0 * M_PI / 64.0;
	for(int i = 0; i < 64; i++)
	{
		float t0 = arc*i;
		float t1 = arc*(i+1);
		vec2_t s0 = vec2_mul(vec2_init(cos(t0), sin(t0)), C1.b.x);
		vec2_t s1 = vec2_mul(vec2_init(cos(t1), sin(t1)), C1.b.x);
		vec2_t p0 = vec2_add(C1.a, s0);
		vec2_t p1 = vec2_add(C1.a, s1);
		lines.push_back(line_init(p0, p1, c));
	}
	return lines;
}

std::vector<line_t> box_trace(shape_t B1, colour_t c)
{
	std::vector<line_t> lines = std::vector<line_t>();
	vec2_t bl = B1.a;
	vec2_t tr = B1.b;
	vec2_t tl = vec2_init(bl.x, tr.y);
	vec2_t br = vec2_init(tr.x, bl.y);
	lines.push_back(line_init(tl, tr, c));
	lines.push_back(line_init(tr, br, c));
	lines.push_back(line_init(br, bl, c));
	lines.push_back(line_init(bl, tl, c));
	return lines;
}
