#pragma once

#include <iostream>
#include <time.h>

float frand(float min, float max)
{
	float core = (float) rand() / (float) RAND_MAX;
	float range = max - min;
	return min + core * range;
}

