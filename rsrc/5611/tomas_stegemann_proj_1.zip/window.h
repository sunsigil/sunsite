#pragma once

#define GLFW_INCLUDE_NONE
#define GLFW_EXPOSE_NATIVE_COCOA

#include <GL/glew.h> 
#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>

#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include "misc/cpp/imgui_stdlib.h"

#include <iostream>

struct window_t
{
	glm::ivec2 pixel_size;
	glm::vec2 meter_size;

	glm::mat4 ndc2meters;
	glm::mat4 meters2ndc;

	GLFWwindow* handle; 	
	ImGuiWindowFlags flags;
};

bool window_init(window_t& window, std::string name, glm::ivec2 pixel_size, glm::vec2 meter_size)
{
	window.pixel_size = pixel_size;
	window.meter_size = meter_size;
	float aspect = meter_size.x / meter_size.y;
	float nx2meters = 2.0f / meter_size.x;
	float ny2meters = aspect * nx2meters;
	window.meters2ndc = glm::scale(glm::vec3(nx2meters, ny2meters, 1));
	window.ndc2meters = glm::scale(glm::vec3(1.0/nx2meters, 1.0/ny2meters, 1));
	window.handle = nullptr;
    
	// Initialize IMGUI
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void) io;
	
	// Configure IMGUI
    ImGui::StyleColorsDark();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
	window.flags =
	ImGuiWindowFlags_NoSavedSettings |
	ImGuiWindowFlags_NoMove |
	ImGuiWindowFlags_NoResize |
	ImGuiWindowFlags_NoSavedSettings |
	ImGuiWindowFlags_NoCollapse |
	ImGuiWindowFlags_NoTitleBar |
	ImGuiWindowFlags_NoBackground;
    
	if(!glfwInit()) 
	{
		std::cerr << "Failed to initialize GLFW" << std::endl;
		return false;
	} 

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
  
	GLFWwindow* handle = glfwCreateWindow(pixel_size.x, pixel_size.y, name.c_str(), NULL, NULL);
	if(!handle) 
	{
		std::cerr << "Failed to open GLFW window" << std::endl;
		glfwTerminate();
		return false;
	}
  	glfwMakeContextCurrent(handle);
	
	ImGui_ImplGlfw_InitForOpenGL(handle, true);
	ImGui_ImplOpenGL3_Init("#version 150");
								  
  	glewExperimental = GL_TRUE;
  	if(glewInit() != GLEW_OK)
	{
		std:: cerr << "Failed to initialize GLEW" << std::endl;
	}

  	const GLubyte* renderer = glGetString(GL_RENDERER);
  	const GLubyte* version = glGetString(GL_VERSION);
  	std::cout << "Renderer: " << renderer << std::endl;
  	std::cout << "OpenGL version: " << version << std::endl;

	window.handle = handle;
	return true;
}

glm::vec2 get_mouse_pos_ndc(window_t& window)
{
	double x, y;
	glfwGetCursorPos(window.handle, &x, &y);
	x /= window.pixel_size.x; y /= window.pixel_size.y;
	return 2.0f * glm::vec2(x - 0.5f, 0.5f - y);
}

glm::vec2 get_mouse_pos_meters(window_t& window)
{
	glm::vec2 mpndc = get_mouse_pos_ndc(window);
	glm::vec4 mpm4 = window.ndc2meters * glm::vec4(mpndc.x, mpndc.y, 0, 0);
	return glm::vec2(mpm4.x, mpm4.y);
}
