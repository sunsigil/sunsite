# 5611 Project 1
## Tomas Stegemann
All code is my own unless stated otherwise, or if it is called from a library.
I credited Christer Ericson for the collision detection methods I took from his book.
