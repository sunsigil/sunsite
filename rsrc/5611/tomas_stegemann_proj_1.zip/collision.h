#pragma once

#include <stdlib.h>
#include <vector>
#include <glm/glm.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtx/projection.hpp>
#include "collider.h"
#include "transform.h"

struct collision_result_t
{
	glm::vec2 position;
	glm::vec2 normal;
};

// BEGIN credit to Real-Time Collision Detection by Christer Ericson
bool circle_circle(collider_t C1, collider_t C2)
{
	float span = C1.b.x+C2.b.x;
	return glm::length2(C2.a - C1.a) <= span*span;
}

float sq_dist_point_box(glm::vec2 p, glm::vec2 min, glm::vec2 max)
{
	float sq_dist = 0.0f;
	if(p.x < min.x)
	{ sq_dist += (min.x - p.x) * (min.x - p.x); }
	if(p.y < min.y)
	{ sq_dist += (min.y - p.y) * (min.y - p.y); }
	if(p.x > max.x)
	{ sq_dist += (p.x - max.x) * (p.x - max.x); }
	if(p.y > max.y)
	{ sq_dist += (p.y - max.y) * (p.y - max.y); }
	return sq_dist;
}

bool circle_box(collider_t C1, collider_t B1)
{
	float sq_dist = sq_dist_point_box(C1.a, B1.a, B1.b);
	return sq_dist <= C1.b.x*C1.b.x;
}
// END Christer Ericson credit

bool test_circle_circle
(
	collider_t C1, collider_t C2,
	transform_t T1, transform_t T2,
	collision_result_t& result
)
{
	C1.a += T1.position;
	C2.a += T2.position;

	if(circle_circle(C1, C2))
	{
		glm::vec2 span = C1.a - C2.a;
		float dist = glm::length(span);
		result.normal = dist > 0 ? span/dist : -glm::normalize(T1.velocity);
		result.position = C2.a + result.normal * C2.b.x;
		return true;
	}
	
	return false;
}

bool point_inside_box(glm::vec2 p, glm::vec2 min, glm::vec2 max)
{
	return
	p.x > min.x && p.x < max.x &&
	p.y > min.y && p.y < max.y;
}

bool test_circle_box
(
	collider_t C1, collider_t C2,
	transform_t T1, transform_t T2,
	collision_result_t& result
)
{
	C1.a += T1.position;
	C2.a += T2.position;
	C2.b += T2.position;

	if(circle_box(C1, C2))
	{
		if(point_inside_box(C1.a, C2.a, C2.b))
		{
			glm::vec2 min_arms = C1.a - C2.a;
			glm::vec2 max_arms = C2.b - C1.a;
			float min_x_dist = fmin(min_arms.x, max_arms.x);
			float min_y_dist = fmin(min_arms.y, max_arms.y);
			float min_dist = fmin(min_x_dist, min_y_dist);
			
			if(min_dist == min_arms.x)
			{ result.position = glm::vec2(C2.a.x, C1.a.y); }
			else if(min_dist == min_arms.y)
			{ result.position = glm::vec2(C1.a.x, C2.a.y); }
			else if(min_dist == max_arms.x)
			{ result.position = glm::vec2(C2.b.x, C1.a.y); }
			else if(min_dist == max_arms.y)
			{ result.position = glm::vec2(C1.a.x, C2.b.y); }

			result.normal = glm::normalize(result.position - C1.a);
		}
		else
		{
			result.position = glm::clamp(C1.a, C2.a, C2.b);
			result.normal = glm::normalize(C1.a - result.position);
		}

		return true;
	}

	return false;
}

void resolve_circle_circle
(
	collider_t C1, collider_t C2,
	transform_t& T1, transform_t& T2,
	collision_result_t result
)
{
	T1.position = result.position + result.normal * C1.b.x * 1.01f;
	glm::vec2 proj = result.normal * glm::dot(T1.velocity, result.normal);
    T1.velocity -= proj * 1.25f;
}

void resolve_circle_box
(
	collider_t C1, collider_t C2,
	transform_t& T1, transform_t& T2,
	collision_result_t result
)
{
	T1.position = result.position + result.normal * C1.b.x * 1.01f;
	glm::vec2 proj = result.normal * glm::dot(T1.velocity, result.normal);
    T1.velocity -= proj * 1.25f;
}

bool run_collision
(
	collider_t S1, collider_t S2,
	transform_t& T1, transform_t& T2,
	collision_result_t& result
)
{
	if(S1.is_static || !S1.is_enabled || !S2.is_enabled)
	{ return false; }

	switch(S1.type)
	{
		case CIRCLE:
		{
			switch(S2.type)
			{
				case CIRCLE:
				{
					if(test_circle_circle(S1, S2, T1, T2, result))
					{
						resolve_circle_circle(S1, S2, T1, T2, result);
						return true;
					}
					break;
				}
				case BOX:
				{
					if(test_circle_box(S1, S2, T1, T2, result))
					{
						resolve_circle_box(S1, S2, T1, T2, result);
						return true;
					}
					break;
				}
			}
		}
	}

	return false;
}

