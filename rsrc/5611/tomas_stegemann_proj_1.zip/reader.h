#pragma once

#include <glm/glm.hpp>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include "scene.h"

std::vector<std::string> lex_obstacle_course(std::string path)
{
	std::vector<std::string> tokens = std::vector<std::string>();
	std::ifstream file = std::ifstream(path);
	std::string line;
	while(std::getline(file, line))
	{
		std::stringstream split = std::stringstream(line);
		std::string token;
		while(split >> token)
		{ tokens.push_back(token); }
	}
	file.close();
	return tokens;
}

void parse_obstacle_course(scene_t& scene, std::string path)
{	
	std::vector<std::string> tokens = lex_obstacle_course(path);
	scene.n_entities = scene.bookmark;

	for(int i = 0; i < tokens.size(); i++)
	{
		if(tokens[i] == "CIRCLE")
		{
			glm::vec2 x = glm::vec2(std::stof(tokens[i+1]), std::stof(tokens[i+2]));
			float r = std::stof(tokens[i+3]);
			int id = add_circle(scene, x, r);
			scene.colliders[id].is_static = true;
			i += 3;
		}
		else if(tokens[i] == "BOX")
		{
			glm::vec2 x = glm::vec2(std::stof(tokens[i+1]), std::stof(tokens[i+2]));
			glm::vec2 dims = glm::vec2(std::stof(tokens[i+3]), std::stof(tokens[i+4]));
			int id = add_box(scene, x, dims);
			scene.colliders[id].is_static = true;
			i += 4;
		}
	}
}
