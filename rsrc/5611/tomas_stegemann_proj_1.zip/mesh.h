#pragma once
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <GL/glew.h> 
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

struct mesh_t
{
	GLuint vao_id;
	GLuint vbo_id;
	std::vector<glm::vec2> verts;
	glm::vec4 colour;
};

std::vector<glm::vec2> circle_trace(float r)
{
	std::vector<glm::vec2> points = std::vector<glm::vec2>();
	float arc = 2.0 * M_PI / 16.0;
	for(int i = 0; i < 16; i++)
	{
		float t0 = arc*i;
		float t1 = arc*(i+1);
		glm::vec2 s0 = r * glm::vec2(cos(t0), sin(t0));
		glm::vec2 s1 = r * glm::vec2(cos(t1), sin(t1));
		points.push_back(s0);
		points.push_back(s1);
	}
	return points;
}

std::vector<glm::vec2> box_trace(glm::vec2 dims)
{
	glm::vec2 bl = -dims*0.5f;
	glm::vec2 tr = dims*0.5f;

	std::vector<glm::vec2> points = std::vector<glm::vec2>();
	glm::vec2 tl = glm::vec2(bl.x, tr.y);
	glm::vec2 br = glm::vec2(tr.x, bl.y);
	points.push_back(tl);
	points.push_back(tr);
	points.push_back(tr);
	points.push_back(br);
	points.push_back(br);
	points.push_back(bl);
	points.push_back(bl);
	points.push_back(tl);

	return points;
}

std::vector<glm::vec2> tri_trace(glm::vec2 a, glm::vec2 b, glm::vec2 c)
{
	glm::vec2 centroid = 0.333333333f * (a+b+c);
	a -= centroid;
	b -= centroid;
	c -= centroid;

	std::vector<glm::vec2> points = std::vector<glm::vec2>();
	points.push_back(a);
	points.push_back(b);
	points.push_back(b);
	points.push_back(c);
	points.push_back(c);
	points.push_back(a);

	return points;
}

mesh_t mesh_init(std::vector<glm::vec2> points)
{
	GLuint vao_id;
	glGenVertexArrays(1, &vao_id);
	glBindVertexArray(vao_id);

	GLuint vbo_id;
	glGenBuffers(1, &vbo_id);
	glBindBuffer(GL_ARRAY_BUFFER, vbo_id);
	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec2) * points.size(), points.data(), GL_STATIC_DRAW);

	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(glm::vec2), (void*) 0);
	glEnableVertexAttribArray(0);
	
	glBindVertexArray(0);

	return (mesh_t) { vao_id, vbo_id, points, glm::vec4(1,1,1,1) };
}

