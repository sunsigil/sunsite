#pragma once

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include "transform.h"
#include "collider.h"
#include "mesh.h"

struct scene_t
{
	transform_t* transforms;
	collider_t* colliders;
	mesh_t* meshes;

	int max_entities;
	int n_entities;
	int bookmark;
};

scene_t scene_init(int max_entities)
{
	scene_t scene;
	scene.transforms = new transform_t[max_entities];
	scene.colliders = new collider_t[max_entities];
	scene.meshes = new mesh_t[max_entities];
	scene.max_entities = max_entities;
	scene.n_entities = 0;
	scene.bookmark = 0;
	return scene;
}

void scene_dispose(scene_t& scene)
{
	delete[] scene.transforms;
	delete[] scene.colliders;
	delete[] scene.meshes;
}

int add_circle(scene_t& scene, glm::vec2 x, float r)
{
	if(scene.n_entities == scene.max_entities)
	{ return -1; }

	int idx = scene.n_entities;
	scene.transforms[idx] = transform_init(x);
	scene.colliders[idx] = circle_collider_init(r);
	scene.meshes[idx] = mesh_init(circle_trace(r));
	scene.n_entities++;

	return idx;
}

int add_box(scene_t& scene, glm::vec2 x, glm::vec2 dims)
{
	if(scene.n_entities == scene.max_entities)
	{ return -1; }

	int idx = scene.n_entities;
	scene.transforms[idx] = transform_init(x);
	scene.colliders[idx] = box_collider_init(dims);
	scene.meshes[idx] = mesh_init(box_trace(dims));
	scene.n_entities++;

	return idx;
}

int add_tri(scene_t& scene, glm::vec2 x, glm::vec2 a, glm::vec2 b, glm::vec2 c)
{
	if(scene.n_entities == scene.max_entities)
	{ return -1; }

	glm::vec2 min = glm::min(a, glm::min(b, c));
	glm::vec2 max = glm::max(a, glm::max(b, c));
	glm::vec2 dims = max-min;

	int idx = scene.n_entities;
	scene.transforms[idx] = transform_init(x);
	scene.colliders[idx] = box_collider_init(dims);
	scene.meshes[idx] = mesh_init(tri_trace(a,b,c));
	scene.n_entities++;

	return idx;
}

void remove_entity(scene_t& scene, int idx)
{
	if(idx < 0 || idx >= scene.n_entities)
	{ return; }
	if(idx == scene.n_entities-1)
	{ scene.n_entities--; return; }

	int last = scene.n_entities-1;

	scene.transforms[idx] = scene.transforms[last];
	scene.colliders[idx] = scene.colliders[last];
	scene.meshes[idx] = scene.meshes[last];
	scene.n_entities--;
}

