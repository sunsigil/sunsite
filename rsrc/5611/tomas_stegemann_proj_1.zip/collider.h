#pragma once
#include <glm/glm.hpp>
#include <glm/gtx/norm.hpp>

enum shape_type_t
{
	CIRCLE,
	BOX
};

struct collider_t
{
	shape_type_t type;
	glm::vec2 a;
	glm::vec2 b;
	bool is_enabled;
	bool is_static;
};

collider_t circle_collider_init(float r)
{ return (collider_t) { CIRCLE, glm::vec2(0,0), glm::vec2(r,r), true, false }; }

collider_t box_collider_init(glm::vec2 dims)
{ return (collider_t) { BOX, -dims*0.5f, dims*0.5f, true, false }; }

