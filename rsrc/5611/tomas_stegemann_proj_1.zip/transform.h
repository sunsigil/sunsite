#pragma once

#include <iostream>
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtx/string_cast.hpp>

struct transform_t
{
	glm::vec2 scale;
	glm::vec2 position;
	glm::vec2 velocity;
	glm::vec2 acceleration;
	float orientation;
};

transform_t transform_init(glm::vec2 position)
{
	transform_t transform;
	transform.scale = glm::vec2(1,1);
	transform.position = position;
	transform.velocity = glm::vec2(0,0);
	transform.acceleration = glm::vec2(0,0);
	transform.orientation = 0;
	return transform;
}

void euler_integrate(transform_t& transform, float dt)
{
	transform.velocity += transform.acceleration * dt;
	transform.position += transform.velocity * dt;
}

glm::mat4 make_matrix(transform_t& transform)
{
	glm::mat4 S1 = glm::scale(glm::vec3(transform.scale.x, transform.scale.y, 1));
	glm::mat4 R1 = glm::rotate(transform.orientation, glm::vec3(0, 0, 1));
	glm::mat4 T2 = glm::translate(glm::vec3(transform.position.x, transform.position.y, 0));
	return T2*R1*S1;
}

