#include <GL/glew.h> 
#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>

#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include "misc/cpp/imgui_stdlib.h"

#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/string_cast.hpp>

#include <iostream>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <float.h>
#include <chrono>
#include <time.h>

#include "collision.h"
#include "mesh.h"
#include "shader.h"
#include "scene.h"
#include "window.h"
#include "reader.h"
#include "cowtools.h"

float timescale = 1.0f;

void clean_oob(scene_t& scene, window_t& window)
{
	for(int i = scene.bookmark; i < scene.n_entities; i++)
	{
		if
		(
			scene.transforms[i].position.x < -window.meter_size.x ||
			scene.transforms[i].position.x > window.meter_size.x ||
			scene.transforms[i].position.y < -window.meter_size.y ||
			scene.transforms[i].position.y > window.meter_size.y
		)
		{
			remove_entity(scene, i); 
			i--;
		}
	}
}

void run_physics(scene_t& scene, float dt)
{
	for(int i = 0; i < scene.n_entities; i++)
	{
		euler_integrate(scene.transforms[i], dt);

		for(int j = 0; j < scene.n_entities; j++)
		{
			if(j == i)
			{ continue; }

			collision_result_t result;
			run_collision
			(
				scene.colliders[i], scene.colliders[j],
				scene.transforms[i], scene.transforms[j],
				result
			);
		}
	}
}

void render_meshes(scene_t& scene, window_t& window, shader_t shader)
{
	glUseProgram(shader.prog_id);
	for(int i = 0; i < scene.n_entities; i++)
	{
		glBindVertexArray(scene.meshes[i].vao_id);
		glm::mat4 transform_mat = make_matrix(scene.transforms[i]);
		transform_mat = window.meters2ndc * transform_mat;
		int transform_loc = glGetUniformLocation(shader.prog_id, "transform");
		glProgramUniformMatrix4fv(shader.prog_id, transform_loc, 1, GL_FALSE, glm::value_ptr(transform_mat));
		int colour_loc = glGetUniformLocation(shader.prog_id, "colour");
		glProgramUniform4fv(shader.prog_id, colour_loc, 1, glm::value_ptr(scene.meshes[i].colour));
		glDrawArrays(GL_LINES, 0, scene.meshes[i].verts.size());
	}
	glBindVertexArray(0);
}

void render_ui(scene_t& scene, window_t& window, float dt)
{
	static std::string scene_path = "";

	ImGui_ImplGlfw_NewFrame();
	ImGui_ImplOpenGL3_NewFrame();
	ImGui::NewFrame();
	ImGui::SetNextWindowPos(ImVec2(0, 0));
	ImGui::SetNextWindowSize(ImVec2(window.pixel_size.x, window.pixel_size.y));
	ImGui::Begin("##windpw", nullptr, window.flags);

	float fps = (1.0f/dt);
	ImGui::PushItemWidth(window.pixel_size.x*0.25f);
	ImGui::InputText("##scene_path", &scene_path);
	ImGui::PopItemWidth();
	ImGui::SameLine();
	if(ImGui::Button("Load"))
	{ parse_obstacle_course(scene, scene_path); }
	ImGui::Text("%d entities at %.0f FPS\n", scene.n_entities, fps);
	ImGui::PushItemWidth(window.pixel_size.x*0.125f);
	ImGui::SliderFloat("##time_scale", &timescale, 0, 1);
	ImGui::PopItemWidth();

	ImGui::End();
	ImGui::Render();
	ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

int main (int argc, char** argv) 
{
	srand(time(NULL));

	// INIT WINDOW
	window_t window;
	if(!window_init(window, "Pinball", glm::ivec2(720, 720), glm::vec2(10, 10)))
	{ return 1; }

	// INIT SCENE
	scene_t scene = scene_init(100);
	int launcher_id = add_tri(scene, glm::vec2(0.0, -4.5f), glm::vec2(0.0f, 1.0f), glm::vec2(0.25f, 0.0f), glm::vec2(-0.25f, 0.0f));
	scene.colliders[launcher_id].is_enabled = false;
	scene.meshes[launcher_id].colour = glm::vec4(1, 0, 0, 1);
	scene.bookmark++;
	
	shader_t shader = load_shader("line.vert", "line.frag");

	std::chrono::time_point<std::chrono::system_clock> last_frame_time = std::chrono::system_clock::now();
	std::chrono::time_point<std::chrono::system_clock> frame_time = std::chrono::system_clock::now();
	std::chrono::duration<float> delta_frame_time;
	
	bool firing = false;
	bool raining = false;
	
	while(!glfwWindowShouldClose(window.handle))
	{
		// TIMING
		frame_time = std::chrono::system_clock::now();
		delta_frame_time = frame_time - last_frame_time;
		last_frame_time = frame_time;
		float dt = delta_frame_time.count() * timescale;	
		
		// INPUT
		glfwPollEvents();
		
		glm::vec2 aim_line = get_mouse_pos_meters(window) - scene.transforms[launcher_id].position;
		float aim_angle = glm::atan(aim_line.y, aim_line.x) - M_PI*0.5f;
		scene.transforms[launcher_id].orientation = aim_angle;

		if(glfwGetKey(window.handle, GLFW_KEY_SPACE) == GLFW_PRESS && !firing)
		{
			firing = true;

			glm::vec2 aim_dir = glm::normalize(aim_line);
			glm::vec2 spawn_pos = scene.transforms[launcher_id].position + aim_dir * 0.5f;

			int ball_id = add_circle(scene, spawn_pos, 0.125f);
			scene.transforms[ball_id].velocity = aim_dir * 15.0f;
			scene.transforms[ball_id].acceleration = glm::vec2(0.0f, -9.81f);
			scene.meshes[ball_id].colour = glm::vec4(1.0f, 0.75f, 0, 1);
		}
		else if(glfwGetKey(window.handle, GLFW_KEY_SPACE) == GLFW_RELEASE)
		{ firing = false; }

		if(glfwGetKey(window.handle, GLFW_KEY_R) == GLFW_PRESS && !raining)
		{
			raining = true;

			for(int i = 0; i < 5; i++)
			{
				float x = -3.5 + (i / 5.0) * 7.0;
				float y = 5.0 + frand(-0.25, 0.25);
				int ball_id = add_circle(scene, glm::vec2(x, y), 0.25f);
				scene.transforms[ball_id].acceleration = glm::vec2(0.0f, -9.81f);
			}
		}
		else if(glfwGetKey(window.handle, GLFW_KEY_R) == GLFW_RELEASE)
		{ raining = false; }
		
		// PHYSICS
		clean_oob(scene, window);
		run_physics(scene, dt);

		// DRAWING
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);
		render_meshes(scene, window, shader);
		render_ui(scene, window, dt);

		glfwSwapBuffers(window.handle);
	}

	shader_dispose(shader);
	scene_dispose(scene);

	ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();

	glfwDestroyWindow(window.handle);
  	glfwTerminate();
  	return 0;
}
